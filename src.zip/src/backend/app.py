# app.py (Finalized Version with External File Loading and Dynamic Logic)

from flask import Flask, jsonify, request
from flask_cors import CORS
from lxml import etree
import json
import os

from XsltLogicTranslator import XsltLogicTranslator

app = Flask(__name__)
# Enable CORS for frontend communication
CORS(app)

# --- Global Configuration Cache ---
CONFIG_CACHE = {}


def load_json_data(filepath_key):
    """
    Loads a JSON file based on a relative path key from the 'data' directory.
    If the file is already loaded, it returns the cached version.
    """
    # Use os.path.join and os.path.dirname(__file__) to safely construct the path
    base_dir = os.path.dirname(__file__)
    full_path = os.path.join(base_dir, 'data', filepath_key)

    # Check cache first
    if full_path in CONFIG_CACHE:
        return CONFIG_CACHE[full_path]

    try:
        # Load the file
        with open(full_path, 'r') as f:
            data = json.load(f)
            # Cache the data
            CONFIG_CACHE[full_path] = data
            return data
    except Exception as e:
        # Print a clear error for debugging missing files
        print(f"ERROR loading {full_path}: {e}")
        # Return appropriate empty structure based on expected content (list or dict)
        return [] if full_path.endswith('TradeState.json') or full_path.endswith('datasource.json') else {}


# --- IMMUTABLE DATA LOADING LAYER ---

# Load the primary config file at startup
JURISDICTIONS_CONFIG = load_json_data('jurisdictions.json')


# --- Utility Functions ---

def xml_to_troy_key_value_sim(xml_tree_root):
    """
    Simulates the Tree XML (Canonical DTCC) to Troy Key-Value mapping.
    (Used by the advanced_transform route)
    """
    troy_data = {}
    for elem in xml_tree_root.iter():
        if elem.text and elem.tag and elem.text.strip():
            key = elem.tag.split('}')[-1]
            troy_data[key] = elem.text.strip()

    # Add simulation for notional for better UI testing
    notional_elem = xml_tree_root.find('.//NotionalAmount')
    if notional_elem is not None and notional_elem.text:
        troy_data['N_NOTIONAL_AMOUNT'] = notional_elem.text

    return troy_data


def process_and_combine_data(dataset):
    """
    Transforms raw field logic data (with dependencies_list, xpath_strings)
    into the structured format required by the UI (with computed code/ref metrics).
    """
    # 1. Process Dependencies: Add computed/simulated metrics
    field_data_set=[]
    asset_class_set=[]
    for data in dataset:
        asset_class=data['assetClass']
        if asset_class not in asset_class_set:
            asset_class_set.append(asset_class)
        processed_deps = []
        for dep in data.get('dependencies_list', []):
            p_dep = dep.copy()

            # Simulate runtime metrics for the UI (code and ref)
            if dep['type'] == 'Field Reference':
                p_dep['code'] = ""
                p_dep['ref'] = 4
            elif dep['type'] in ['Template', 'Function', 'Variable']:
                p_dep['code'] = ""
                p_dep['ref'] = 2

            processed_deps.append(p_dep)

        # 2. Process XPaths: Convert raw list of strings to structured objects
        processed_paths = []
        for number in range(1, 31):
            for idx, path in enumerate(data.get('xpath_strings', [])):
                processed_paths.append({
                    "xpath": path,
                    # Simulated computed metadata
                    "name": f"Source Field {idx + 1}",
                    "type": "Data Source" if idx == 0 else "Reference",
                    "source": f"Config File {idx + 1}.json"
                })

        # 3. Combine with original keys and return
        # Lineage structure removed as requested in earlier steps.
        field_data= {
            "codeSnippet": data.get('codeSnippet'),
            "sourceFile": data.get('sourceFile'),
            "type": data.get('type'),
            "assetClass": data.get('assetClass'),
            "dependencies": processed_deps,
            "xpaths": processed_paths
        }
        field_data_set.append(field_data)
    return asset_class_set,field_data_set


# --- API ENDPOINTS ---

@app.route('/api/jurisdictions', methods=['GET'])
def get_jurisdictions():
    """Returns the list of jurisdictions and their available report types."""

    # Transform the loaded config to the required frontend format (list of jurisdictions and types)
    transformed_output = []
    for j in JURISDICTIONS_CONFIG:
        # Extract only the names of the reports
        report_names = [r['name'] for r in j.get('report', [])]
        transformed_output.append({
            "jurisdiction": j['jurisdiction'],
            "types": report_names
        })
    return jsonify(transformed_output)


@app.route('/api/fields', methods=['GET'])
def get_fields():
    """
    Returns fields based on jurisdiction and report type
    by loading the specific report file (e.g., config/jfsa/TradeState.json).
    """
    jurisdiction = request.args.get('jurisdiction')
    config_type = request.args.get('type')

    j_config = next((j for j in JURISDICTIONS_CONFIG if j['jurisdiction'] == jurisdiction), None)
    if not j_config:
        return jsonify([]), 404

    # Find the report path
    report_config = next((r for r in j_config.get('report', []) if r['name'] == config_type), None)
    if not report_config:
        return jsonify([]), 404

    # Load the field list from the file specified by the path
    field_list_data = load_json_data(report_config['path'])

    # Transform the loaded list into the UI's required format (id/name)
    data_key = j_config.get('dataSourceKey', 'FieldName')  # Default to 'FieldName'
    display_key = j_config.get('displayKey', 'FieldDesc')  # Default to 'FieldDesc'

    transformed_fields = []
    for item in field_list_data:
        # Map the dynamic keys to the fixed 'id' and 'name' required by the frontend
        transformed_fields.append({
            "id": item.get(data_key),
            "name": item.get(display_key)
        })

    return jsonify(transformed_fields)


@app.route('/api/field-details/<field_id>', methods=['GET'])
def get_field_details(field_id):
    """
    Fetches field logic details by loading the 'datasource.json' array
    for that jurisdiction and searching the array for the matching field_id.
    """
    jurisdiction = request.args.get('jurisdiction')

    if not jurisdiction:
        return jsonify({"error": "Missing jurisdiction parameter."}), 400

    j_config = next((j for j in JURISDICTIONS_CONFIG if j['jurisdiction'] == jurisdiction), None)
    if not j_config:
        return jsonify({"error": "Jurisdiction config not found."}), 404

    # 1. Load the specific datasource file (which is an array)
    datasource_path = j_config['datasource']
    datasource_logic_array = load_json_data(datasource_path)

    # 2. Search the array for the field with the matching 'name' (field_id)
    raw_data = [
        item for item in datasource_logic_array
        if item.get('name') == field_id
    ]

    if not raw_data:
        # Return empty data if not found
        return jsonify({
            "assetClasses": [],
            "fields": []
        })

    # 3. Process the raw data into the UI format
    asset_class_set,processed_details = process_and_combine_data(raw_data)
    output={ "assetClasses":asset_class_set,"fields":processed_details}
    return jsonify(output)


@app.route('/api/transform', methods=['POST'])
def transform_xml():
    """Accepts XML and XSLT and returns the transformed XML output (Simple Test)."""
    data = request.json
    xml_data = data.get('xml')
    xslt_code = data.get('xslt')

    if not xml_data or not xslt_code:
        return jsonify({"error": "Missing XML or XSLT code."}), 400

    try:
        xml_root = etree.fromstring(xml_data.encode('utf-8'))
        xslt_root = etree.fromstring(xslt_code.encode('utf-8'))
        transform = etree.XSLT(xslt_root)
        result_tree = transform(xml_root)

        transformed_xml = etree.tostring(
            result_tree,
            pretty_print=True,
            encoding='unicode'
        )

        return jsonify({"result": transformed_xml})

    except etree.XMLSyntaxError as e:
        return jsonify({"error": f"XML/XSLT Syntax Error: {str(e)}"}), 400
    except Exception as e:
        return jsonify({"error": f"Transformation Error: {str(e)}"}), 500


@app.route('/api/advanced-transform', methods=['POST'])
def advanced_transform():
    """Handles FO XML -> Trade Service XML -> Troy Key-Value stages (Complex Test)."""
    data = request.json
    xml_fo_data = data.get('xml_fo')
    xslt_code = data.get('xslt')

    if not xml_fo_data or not xslt_code:
        return jsonify({"error": "Missing FO XML or XSLT code."}), 400

    results = {
        "trade_service_xml": "",
        "troy_key_value": {}
    }

    try:
        # Stage 1: Transformation (FO XML -> Trade Service XML)
        xml_root = etree.fromstring(xml_fo_data.encode('utf-8'))
        xslt_root = etree.fromstring(xslt_code.encode('utf-8'))
        transform = etree.XSLT(xslt_root)
        result_tree = transform(xml_root)

        results["trade_service_xml"] = etree.tostring(
            result_tree,
            pretty_print=True,
            encoding='unicode'
        )

        # Stage 2: Mapping (Trade Service XML -> Key-Value)
        results["troy_key_value"] = xml_to_troy_key_value_sim(result_tree)

        return jsonify(results)

    except etree.XMLSyntaxError as e:
        return jsonify({"error": f"XML/XSLT Syntax Error: {str(e)}"}), 400
    except Exception as e:
        return jsonify({"error": f"Transformation Error: {str(e)}"}), 500

# --- Conceptual Data Structures (Simulating a Database/File System) ---

# Mock data store for field logic and dependencies
# Realistically, this would be queried from a DB or file contents.
MOCK_LOGIC_STORE = {
    "US_RATE_FIELD_A": {
        "asset_class": "Rates",
        "dependencies": ["XSLT_VAR_CALC", "XSLT_FUNC_GET_PRICE"],
        "asset_class_dependencies": {}
    },
    "XSLT_VAR_CALC": {
        "asset_class": "Common",
        "dependencies": ["XSLT_FUNC_VALIDATE_DATE", "XSLT_TMPL_GET_ID"],
        "asset_class_dependencies": {}
    },
    "XSLT_FUNC_GET_PRICE": {
        "asset_class": "Rates",
        "dependencies": ["DB_LOOKUP_PRICE"],
        "asset_class_dependencies": {}
    },
    "XSLT_TMPL_GET_ID": {
        "asset_class": "Common",
        "dependencies": [],
        "asset_class_dependencies": {}
    },
    "DB_LOOKUP_PRICE": {
        "asset_class": "Database",
        "dependencies": [],
        "asset_class_dependencies": {}
    },
    "XSLT_FUNC_VALIDATE_DATE": {
        "asset_class": "Common",
        "dependencies": [],
        "asset_class_dependencies": {}
    }
}

# Mapping of component name to a group/type for visualization
MOCK_GROUP_MAPPING = {
    "XSLT_VAR": "variable",
    "XSLT_FUNC": "template",
    "XSLT_TMPL": "template",
    "DB_LOOKUP": "database",
    "FIELD": "field",
}

def _get_group(component_id):
    """Assigns a group for visualization based on component ID prefix."""
    for prefix, group in MOCK_GROUP_MAPPING.items():
        if component_id.startswith(prefix):
            return group
    return "unknown"

def _get_dependency_hierarchy(component_id, max_depth=3, visited=None, depth=0):
    """
    CONCEPTUAL IMPLEMENTATION of the recursive dependency lookup.

    This function simulates traversing the dependency graph up to max_depth.
    It returns a flattened list of all unique nodes and edges found.
    """
    if visited is None:
        visited = set()

    if component_id in visited or depth >= max_depth:
        return {'nodes': [], 'edges': []}

    visited.add(component_id)

    component_logic = MOCK_LOGIC_STORE.get(component_id)
    if not component_logic:
        return {'nodes': [], 'edges': []}

    local_nodes = []
    local_edges = []

    # 1. Add the current node
    local_nodes.append({
        "id": component_id,
        "label": component_id,
        "group": _get_group(component_id)
    })

    # 2. Process dependencies
    dependencies = component_logic.get("dependencies", [])

    for dep_id in dependencies:
        # Add the edge from current component to its dependency
        local_edges.append({
            "source": component_id,
            "target": dep_id,
            "type": "uses"
        })

        # Recursively find dependencies of the dependency
        sub_graph = _get_dependency_hierarchy(dep_id, max_depth, visited, depth + 1)

        # Merge sub-graph nodes and edges
        local_nodes.extend(sub_graph['nodes'])
        local_edges.extend(sub_graph['edges'])

    return {'nodes': local_nodes, 'edges': local_edges}

@app.route('/api/graph', methods=['GET'])
def get_graph_data():
    """
    Endpoint to fetch the dependency graph data for a specific field.
    The frontend is calling this endpoint via dtccApi.getGraphData().
    """
    field_id = request.args.get('field_id')
    jurisdiction = request.args.get('jurisdiction')
    asset_class = request.args.get('asset_class')  # asset_class is optional

    if not field_id or not jurisdiction:
        return jsonify({"error": "Missing field_id or jurisdiction parameter"}), 400

    print(f"Fetching graph for: {jurisdiction}/{field_id}, Asset Class: {asset_class}")

    # --- 1. Fetch Dependency Hierarchy ---
    # Start the recursive lookup from the initial field_id.
    # The 'root' node should be treated specially for visualization.

    full_graph = _get_dependency_hierarchy(field_id, max_depth=3)

    # --- 2. Final Formatting and De-duplication ---

    # De-duplicate nodes and edges to ensure a clean graph structure
    unique_nodes = {node['id']: node for node in full_graph['nodes']}

    # Ensure the root node is marked correctly
    if field_id in unique_nodes:
        unique_nodes[field_id]['group'] = 'root'
    else:
        # If the root isn't in MOCK_LOGIC_STORE, add it manually
        unique_nodes[field_id] = {"id": field_id, "label": field_id, "group": "root"}

    # Create final graph data structure
    graph_data = {
        "nodes": list(unique_nodes.values()),
        # Simple deduplication for edges (optional, but good practice)
        "edges": list({tuple(sorted(edge.items())): edge for edge in full_graph['edges']}.values())
    }

    # Return the data to the frontend
    return jsonify(graph_data)


@app.route('/api/translate-xslt', methods=['POST'])
def translate_xslt():
    """Receives an XSLT snippet and returns a business explanation."""
    data = request.get_json()
    xslt_snippet = data.get('xslt_snippet', '')

    if not xslt_snippet:
        return jsonify({"error": "No XSLT snippet provided."}), 400

    try:
        translator = XsltLogicTranslator()
        business_explanation = translator.translate_xslt_to_business_logic(xslt_snippet)

        return jsonify({
            "explanation": business_explanation
        })
    except Exception as e:
        print(f"Error during XSLT translation: {e}")
        return jsonify({"error": "Failed to process the XSLT snippet."}), 500

@app.route('/api/xpath-analysis', methods=['POST'])
def get_impact_analysis():
    """
    Handles dtccApi.fetchFieldImpactAnalysis().
    Performs a reverse search to find all downstream fields depending on the current field.
    """
    jurisdiction = request.args.get('jurisdiction')
    field_id = request.args.get('field_id')
    asset_class = request.args.get('asset_class')

    print(f"Received Impact Analysis Request: J={jurisdiction}, ID={field_id}, AC={asset_class}")


    return jsonify([
            {"fieldId": "RPT_RATES_01", "fieldName": "Daily Reporting Rates", "sourceFile": "reports/rates_rpt.xsl", "assetClass": "Rates"},
            {"fieldId": "AUDIT_005A", "fieldName": "Audit Trail Value 5A", "sourceFile": "audit/master_log.xsl", "assetClass": "Rates"},
            {"fieldId": "RISK_ADJ_FACTOR", "fieldName": "Adjusted Risk Factor", "sourceFile": "risk/factor_calc.xsl", "assetClass": "Rates"}
        ])


# analysis_core.py (Conceptual - Placeholder for your business logic)

def run_xpath_impact_analysis(xpath: str, jurisdiction: str, report_type: str) -> list:
    """
    Performs the complex logic of determining which downstream report fields
    are influenced by the given XPath expression within the provided context.
    """

    # 🚨 CRITICAL: Add robust XPath sanitization and security checks here
    # to prevent XPath injection attacks (Source 1.1, 1.4, 2.2).

    if "doc(" in xpath:
        raise ValueError("XPath function 'doc()' is forbidden for security reasons.")

    # --- Actual Lineage Logic Placeholder ---

    # In a real system, this would involve:
    # 1. Querying a lineage graph database (like Neo4j) or a relational database.
    # 2. Executing logic to infer impacted target paths based on the source XPath.

    # Example simulated result based on input
    if "TradeHeader" in xpath and jurisdiction == "US":
        return [
            {"fieldId": "R001", "fieldName": "Reporting Counterparty ID", "sourceFile": "TradeService.xslt", "assetClass": "Credit"},
            {"fieldId": "R010", "fieldName": "Trade Date", "sourceFile": "TradeService.xslt", "assetClass": "All"},
        ]
    elif "TradeBody" in xpath and report_type == "FX":
        return [
            {"fieldId": "R150", "fieldName": "FX Rate", "sourceFile": "FXService.xslt", "assetClass": "FX"},
        ]
    else:
        # Default or no impact found
        return []




if __name__ == '__main__':
    # Flask app will run on port 5001, allowing the React app on 3000 to connect
    app.run(debug=True, port=5001)