import re
import html  # Required for unescaping HTML entities like &gt;


class XsltLogicTranslator:
    """
    Translates XSLT flow control into a highly structured Markdown string
    modeling the If/Else If/Else conditional logic.
    """

    def __init__(self):
        # Configuration for identifying the main logic structure
        self.translation_map = {
            r'<xsl:choose>': {
                "name": "Decision Tree (Conditional Logic)",
                "explanation": "This block is a Decision Tree used to check multiple conditions sequentially. The system executes the instructions of the **first condition** that is met.",
                "rules": []
            },
        }

    def _get_operator_translation(self, condition):
        """
        Translates technical XSLT operators into plain English while protecting
        variables and preventing replacement bleed.
        """

        condition = html.unescape(condition).strip()

        # 1. TEMPORARILY MASK VARIABLES
        condition_with_masked_vars = re.sub(r'\$(\w+)', r'VAR_\1_VAR', condition)

        # 2. TRANSLATE OPERATORS (Longest operators first)
        condition_with_masked_vars = condition_with_masked_vars.replace('<=', ' is less than or equal to ')
        condition_with_masked_vars = condition_with_masked_vars.replace('<', ' is less than ')
        condition_with_masked_vars = condition_with_masked_vars.replace('>=', ' is greater than or equal to ')
        condition_with_masked_vars = condition_with_masked_vars.replace('>', ' is greater than ')
        condition_with_masked_vars = condition_with_masked_vars.replace('!=', ' does not equal ')
        condition_with_masked_vars = condition_with_masked_vars.replace('=', ' equals ')

        # 3. UNMASK VARIABLES AND ADD Markdown formatting
        # Use Markdown backticks (`) for variables.
        final_condition = re.sub(r'VAR_(\w+)_VAR', r'the value of `\1`', condition_with_masked_vars)

        # 4. Clean up and apply bold formatting to operators
        final_condition = re.sub(r'\s+', ' ', final_condition).strip()
        final_condition = final_condition.replace(' is ', ' **is** ').replace(' does ', ' **does** ')

        return final_condition

    # --- NEW METHOD: Generates Markdown Structure ---
    def _generate_markdown_flow(self, parsed_logic):
        """Generates the structured Markdown text for the decision flow."""

        markdown_lines = []

        # 1. Add overall description
        markdown_lines.append(f"## 🚦 {parsed_logic['name']}")
        markdown_lines.append(f"> **Rule Logic:** {parsed_logic['explanation']}")
        markdown_lines.append("---")

        for idx, rule in enumerate(parsed_logic['rules']):
            condition_text = rule['condition'].replace('**IF** ', '')
            # Extract clean action text
            action_text = rule['action'].replace('Then set the final value to: **', '') \
                .replace('Then set the final default value to: **', '') \
                .strip('*')

            # Escape internal Markdown formatting in action text
            action_text = action_text.replace('*', '\\*').replace('_', '\\_')

            if rule['condition'].startswith('**IF** none'):
                # xsl:otherwise (ELSE)
                markdown_lines.append(f"### ➡️ ELSE (Default Case)")
                markdown_lines.append(f"* **Condition:** None of the above conditions were met.")
                markdown_lines.append(f"* **Output Value:** `{action_text}`")
            elif idx == 0:
                # First xsl:when (IF)
                markdown_lines.append(f"### 🎯 IF (Rule {idx + 1})")
                markdown_lines.append(f"* **Condition:** {condition_text}")
                markdown_lines.append(f"* **Output Value:** `{action_text}`")
            else:
                # Subsequent xsl:when (ELSE IF)
                markdown_lines.append(f"### ➡️ ELSE IF (Rule {idx + 1})")
                markdown_lines.append(f"* **Condition:** {condition_text}")
                markdown_lines.append(f"* **Output Value:** `{action_text}`")

        markdown_lines.append("---")

        return "\n".join(markdown_lines)

    def translate_xslt_to_business_logic(self, xslt_snippet):
        """ Parses the XSLT snippet and generates a detailed Markdown report."""

        if not xslt_snippet:
            return {"error": "No XSLT code provided for translation."}

        # --- 1. Identify Core Structure (xsl:choose) ---
        business_logic = None
        for pattern, config in self.translation_map.items():
            if re.search(pattern, xslt_snippet, re.IGNORECASE | re.DOTALL):
                business_logic = config.copy()
                break

        if not business_logic:
            return {"error": "Could not identify the core XSLT control flow (xsl:choose) in the snippet."}

        # --- 2. Extract Rules (xsl:when and xsl:otherwise) ---
        rules_pattern = r'<xsl:when\s+test\s*=\s*"(.*?)"\s*>(.*?)</xsl:when>|<xsl:otherwise\s*>(.*?)</xsl:otherwise>'

        for match in re.finditer(rules_pattern, xslt_snippet, re.IGNORECASE | re.DOTALL):

            if match.group(1) is not None:  # xsl:when rule matched
                raw_condition = match.group(1).strip()
                action_content = match.group(2).strip()
                english_condition = self._get_operator_translation(raw_condition)
                action_text = action_content if action_content else "No action defined"

                business_logic["rules"].append({
                    "condition": f"**IF** {english_condition}",
                    "action": f"Then set the final value to: **{action_text}**"
                })

            elif match.group(3) is not None:  # xsl:otherwise rule matched
                action_content = match.group(3).strip()
                action_text = action_content if action_content else "No default action defined"

                business_logic["rules"].append({
                    "condition": "**IF** none of the above conditions were met",
                    "action": f"Then set the final default value to: **{action_text}**"
                })

        # --- 3. Generate Markdown String ---
        markdown_output = self._generate_markdown_flow(business_logic)

        # --- 4. Final Return ---
        # Returns the raw Markdown code as explanation_text
        return {

                "explanation_markdown": markdown_output,  # NEW KEY
                "explanation_html": ""  # Clear previous HTML/PlantUML keys

        }