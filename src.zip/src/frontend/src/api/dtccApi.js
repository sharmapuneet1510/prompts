// src/api/dtccApi.js

import axios from 'axios';

// IMPORTANT: Ensure this URL matches your Flask backend port (default 5001)
const API_BASE_URL = 'http://localhost:5001/api';

const dtccApi = {
    // 1. Fetch Jurisdictions
    async getJurisdictions() {
        try {
            const response = await axios.get(`${API_BASE_URL}/jurisdictions`);
            return response.data;
        } catch (error) {
            console.error('Error fetching jurisdictions:', error);
            throw error;
        }
    },

    // 2. Fetch Fields
    async getFields(jurisdiction, type) {
        if (!jurisdiction || !type) {
            console.error('getFields requires both jurisdiction and type.');
            return [];
        }
        try {
            const response = await axios.get(`${API_BASE_URL}/fields`, {
                params: {
                    jurisdiction: jurisdiction,
                    type: type
                }
            });
            return response.data;
        } catch (error) {
            console.error(`Error fetching fields for ${jurisdiction}/${type}:`, error);
            throw error;
        }
    },

    // 3. Fetch Field Details
    async getFieldDetails(jurisdiction, fieldId) {
        if (!jurisdiction || !fieldId) {
            console.error('getFieldDetails requires both jurisdiction and fieldId.');
            return null;
        }
        try {
            const response = await axios.get(`${API_BASE_URL}/field-details/${fieldId}`, {
                params: {
                    jurisdiction: jurisdiction
                }
            });
            return response.data;
        } catch (error) {
            console.error(`Error fetching details for ${jurisdiction}/${fieldId}:`, error);
            throw error;
        }
    },

    // 4. Basic Transformation
    async runTransformation(xml, xslt) {
        try {
            const response = await axios.post(`${API_BASE_URL}/transform`, {
                xml: xml,
                xslt: xslt
            });
            return response.data;
        } catch (error) {
            console.error('Error running transformation:', error);
            throw error;
        }
    },

    // 5. Advanced Transformation
    async runAdvancedTransformation(xmlFoInput, xsltFoToTradeService) {
        try {
            const response = await axios.post(`${API_BASE_URL}/advanced-transform`, {
                xml_fo: xmlFoInput,
                xslt: xsltFoToTradeService
            });
            return response.data;
        } catch (error) {
            console.error('Error running advanced transformation:', error);
            throw error;
        }
    },

    // 6. Fetch Dependency Graph Data
    async getGraphData(jurisdiction, fieldId, assetClass) {
        if (!jurisdiction || !fieldId) {
            console.error('getGraphData requires both jurisdiction and fieldId.');
            return { nodes: [], edges: [] };
        }

        try {
            const response = await axios.get(`${API_BASE_URL}/graph`, {
                params: {
                    jurisdiction: jurisdiction,
                    field_id: fieldId,
                    ...(assetClass && { asset_class: assetClass })
                }
            });
            return response.data;
        } catch (error) {
            console.error(`Error fetching graph data for ${fieldId} (${assetClass}):`, error);
            throw error;
        }
    },

    // 7. XSLT Translation
    async translateXsltToEnglish(xsltSnippet) {
        try {
            const response = await axios.post(`${API_BASE_URL}/translate-xslt`, {
                xslt_snippet: xsltSnippet
            });
            return response.data.explanation;
        } catch (error) {
            console.error('Error translating XSLT:', error);
            return `Translation Error: Failed to connect to the translation service.`;
        }
    },

    // 8. Field Impact Analysis Data (Reverse Dependency)
    async fetchFieldImpactAnalysis(jurisdiction, fieldId, assetClass) {
        if (!jurisdiction || !fieldId || !assetClass) {
            console.error('fetchFieldImpactAnalysis requires jurisdiction, fieldId, and assetClass.');
            return [];
        }

        try {
            const response = await axios.get(`${API_BASE_URL}/impact-analysis`, {
                params: {
                    jurisdiction: jurisdiction,
                    field_id: fieldId,
                    asset_class: assetClass
                }
            });
            return response.data;
        } catch (error) {
            console.error(`Error fetching impact analysis for ${fieldId} (${assetClass}):`, error);
            throw error;
        }
    },

    // <<< 9. NEW ADDITION: XPath Impact Analysis (SYNTAX AND AXIOS FIX) >>>
    /**
     * Calls the DTCC API to find all fields impacted by an arbitrary XPath expression.
     * @param {string} xpath - The arbitrary XPath expression to analyze.
     * @param {string} jurisdiction - The selected regulatory jurisdiction.
     * @param {string} type - The selected report type.
     * @returns {Promise<Array<Object>>} - The list of impacted fields.
     */
    async fetchXPathImpactAnalysis(xpath, jurisdiction, type) {
        if (!xpath) {
            console.error('fetchXPathImpactAnalysis requires an XPath expression.');
            return [];
        }

        try {
            // Using axios.post for the analysis endpoint
            const response = await axios.post(`${API_BASE_URL}/xpath-analysis`, {
                xpath: xpath,
                jurisdiction: jurisdiction,
                type: type,
            });

            // Axios automatically handles JSON parsing and error response status checking
            // The backend is expected to return the list of impacted fields directly in response.data
            return response.data.impactedFields || response.data;

        } catch (error) {
            // Check for a server response error and throw it
            if (error.response) {
                const errorMessage = error.response.data.message || `Server Error: ${error.response.status}`;
                throw new Error(errorMessage);
            }
            console.error('Error analyzing XPath:', error);
            throw new Error(error.message || 'Failed to connect to the analysis service.');
        }
    }
};

export default dtccApi;