import React from 'react';
// 🛑 FIX IS HERE: The client package is imported directly from the react-dom package.
import ReactDOM from 'react-dom/client';
import App from './App';
import './index.css';

// --- Setup for React 18 ---

// 1. Get the root DOM element from public/index.html
const container = document.getElementById('root');

// Safety check
if (!container) {
    throw new Error('Failed to find the root element with ID "root"');
}

// 2. Create a React root object for rendering
const root = ReactDOM.createRoot(container);

// 3. Render the main App component into the root
root.render(
  <React.StrictMode>
    <App />
  </React.StrictMode>
);