// src/hooks/useDashboardLogic.js

import { useState, useEffect, useCallback, useMemo } from 'react';
import dtccApi from '../api/dtccApi';

const useDashboardLogic = () => {

    const [jurisdictions, setJurisdictions] = useState([]);
    const [fields, setFields] = useState([]);
    const [selectedJurisdiction, setSelectedJurisdiction] = useState(null);
    const [selectedType, setSelectedType] = useState(null);
    const [selectedField, setSelectedField] = useState(null);

    // fieldDetails is the array of logic objects (dataArray.fields)
    const [fieldDetails, setFieldDetails] = useState(null);

    // NEW STATE: List of asset classes available from the API (dataArray.assetClasses)
    const [availableAssetClasses, setAvailableAssetClasses] = useState([]); // Initialized to empty array

    // Tracks the currently selected asset class string (e.g., 'Credit')
    const [selectedAssetClass, setSelectedAssetClass] = useState(null);

    const [isLoading, setIsLoading] = useState(false);
    const [error, setError] = useState(null);

    // --- State for Dependency Graph ---
    const [graphData, setGraphData] = useState(null);
    const [isGraphLoading, setIsGraphLoading] = useState(false);
    const [graphError, setGraphError] = useState(null);
    // ---------------------------------


    // --- 2. Field List Fetcher ---
    const fetchFields = useCallback(async (jurisdiction, type) => {
        setIsLoading(true);
        setError(null);
        try {
            const data = await dtccApi.getFields(jurisdiction, type);
            setFields(data);
        } catch (err) {
            setError(`Failed to load fields for ${jurisdiction} / ${type}.`);
            setFields([]);
        } finally {
            setIsLoading(false);
        }
    }, []);

    // --- 1. Initial Load: Fetch Jurisdictions ---
    useEffect(() => {
        const fetchJurisdictions = async () => {
            try {
                const data = await dtccApi.getJurisdictions();
                setJurisdictions(data);

                if (data.length > 0) {
                    const defaultJurisdiction = data[0].jurisdiction;
                    setSelectedJurisdiction(defaultJurisdiction);

                    const defaultType = data[0].types[0];
                    setSelectedType(defaultType);

                    fetchFields(defaultJurisdiction, defaultType);
                }
            } catch (err) {
                setError('Failed to load initial jurisdictions.');
            }
        };
        fetchJurisdictions();
    }, [fetchFields]);

    // --- 3. Jurisdiction & Type Change Handler ---
    const handleSelectChange = useCallback((newJurisdiction, newType) => {

        if (newJurisdiction !== selectedJurisdiction || newType !== selectedType) {

            setSelectedJurisdiction(newJurisdiction);
            setSelectedType(newType);

            setSelectedField(null);
            setFieldDetails(null);
            setSelectedAssetClass(null); // Clear asset class on top-level context change
            setAvailableAssetClasses([]); // Clear available asset classes

            fetchFields(newJurisdiction, newType);
        }
    }, [selectedJurisdiction, selectedType, fetchFields]);

    // --- 4. Field Details Fetcher (FIXED AND ESLINT-COMPLIANT) ---
    const fetchFieldDetails = useCallback(async (fieldId) => {
        if (!selectedJurisdiction) return;

        setIsLoading(true);
        setError(null);
        setSelectedAssetClass(null); // Reset before fetch
        setAvailableAssetClasses([]); // Reset list

        try {
            // API returns an object: { assetClasses: [...], fields: [...] }
            const apiResponse = await dtccApi.getFieldDetails(selectedJurisdiction, fieldId);

            const fetchedAssetClasses = apiResponse.assetClasses || [];
            const fetchedFieldDetails = apiResponse.fields || [];

            // 1. Set the array of available asset class strings
            setAvailableAssetClasses(fetchedAssetClasses);

            // 2. Set the array of logic detail objects
            setFieldDetails(fetchedFieldDetails);

            // 3. Automatically select the first asset class if available
            if (fetchedAssetClasses.length > 0)
            {
                // console.log("Selected AssetClass "+fetchedAssetClasses[0]) // Console log for debugging
                setSelectedAssetClass(fetchedAssetClasses[0]);
            }

            // console.log("Setting available AssetClasses: " + fetchedAssetClasses.join(', ')); // Console log for debugging


        } catch (err) {
            setError(`Failed to load details for field ID: ${fieldId} in ${selectedJurisdiction}.`);
            setFieldDetails(null);
            setAvailableAssetClasses([]);
        } finally {
            setIsLoading(false);
        }
    }, [selectedJurisdiction]); // Only depends on selectedJurisdiction

    // --- 5. Field Selection Handler ---
    const selectField = useCallback((field) => {
        setSelectedField(field);
        if (field && field.id) {
            fetchFieldDetails(field.id);
        } else {
            setFieldDetails(null);
        }
    }, [fetchFieldDetails]);

    // --- 6. NEW: Asset Class Selection Handler ---
    const handleAssetClassSelect = useCallback((assetClass) => {
        setSelectedAssetClass(assetClass);
    }, []);

    // --- 7. NEW: Graph Data Fetcher ---
    const fetchGraphData = useCallback(async (fieldId, assetClass) => {
        if (!selectedJurisdiction) return;

        setIsGraphLoading(true);
        setGraphError(null);
        setGraphData(null); // Clear previous graph

        try {
            // API CALL: Fetches the dependency graph data
            const data = await dtccApi.getGraphData(selectedJurisdiction, fieldId, assetClass);

            // Check if the data is valid (nodes/edges exist)
            if (data && data.nodes && data.edges) {
                setGraphData(data);
            } else {
                 // Handle case where API returns empty but successful response
                setGraphError("No graph data found for this configuration.");
                setGraphData(null);
            }

        } catch (err) {
            // Improved error logging/message extraction
            setGraphError(`Failed to load dependency graph: ${err.message || err.toString()}`);
            setGraphData(null);
        } finally {
            setIsGraphLoading(false);
        }
    }, [selectedJurisdiction]);

    // --- 8. NEW: Translation Fetcher (Fixed for Markdown Output) ---
    const translateXsltToEnglish = useCallback(async (xsltSnippet) => {
        try {
            const response = await dtccApi.translateXsltToEnglish(xsltSnippet);

            // The API is expected to return an object structure that contains the final explanation.
            // We pass the response directly, and the UI component will extract the markdown.
            return response;

        } catch (error) {
            console.error("Translation API Error:", error);
            // Return a structured error object for the consuming component
            return {
                explanation: {
                    explanation_markdown: "Error: Failed to connect to the translation service or API failed.",
                }
            };
        }
    }, []);

    // --- 9. NEW: Impact Analysis Fetcher ---
    /**
     * Calls the DTCC API to find all downstream fields impacted by the current field.
     * This handler will be passed to FieldImpactAnalysisModal.
     * @param {string} fieldId - The ID of the field to analyze.
     * @param {string} assetClass - The asset class context.
     * @returns {Promise<Array<Object>>} - The list of impacted fields.
     */
    const fetchImpactAnalysis = useCallback(async (fieldId, assetClass) => {
        if (!selectedJurisdiction || !fieldId || !assetClass) {
            console.error("Impact Analysis handler missing required parameters (Jurisdiction, Field ID, or Asset Class).");
            return [];
        }

        // The modal component manages its own loading/error state, so this handler only performs the fetch.
        try {
            const results = await dtccApi.fetchFieldImpactAnalysis(
                selectedJurisdiction,
                fieldId,
                assetClass
            );
            return results;
        } catch (error) {
            // Re-throw the error so the calling component (modal) can catch and display it.
            throw new Error(`Impact Analysis API Failed: ${error.message || error.toString()}`);
        }
    }, [selectedJurisdiction]);

    // --- 10. NEW: XPath Impact Analysis Fetcher ---
    /**
     * Calls the DTCC API to find all fields impacted by an arbitrary XPath expression.
     * This handler is used by the standalone XPathImpactAnalysisPage.
     * @param {string} xpath - The arbitrary XPath expression to analyze.
     * @param {string} source - Contextual source of the XPath (e.g., file name or 'Manual Input').
     * @returns {Promise<Array<Object>>} - The list of impacted fields.
     */
    const fetchXPathImpactAnalysis = useCallback(async (xpath, source) => {
        if (!xpath || xpath.trim() === '') {
            throw new Error("XPath expression cannot be empty.");
        }

        // The component manages its own loading/error state.
        try {
            // Assuming your dtccApi exposes a specific function for this endpoint
            const results = await dtccApi.fetchXPathImpactAnalysis(
                xpath,
                // You might need to pass selectedJurisdiction/selectedType if the API needs global context
                selectedJurisdiction,
                selectedType
            );

            // The API is expected to return an array of impacted field objects
            return results || [];
        } catch (error) {
            // Re-throw the error for the consuming component to display.
            throw new Error(`XPath Analysis API Failed: ${error.message || error.toString()}`);
        }
    }, [selectedJurisdiction, selectedType]); // Include global context dependencies if used in API call

    // Combine all exposed handlers into a single object for consumption
    const handlers = useMemo(() => ({
        handleSelectChange,
        selectField,
        handleAssetClassSelect,
        fetchGraphData,
        translateXsltToEnglish,
        fetchXPathImpactAnalysis, // EXPOSED: The new Impact Analysis handler
    }), [
        handleSelectChange,
        selectField,
        handleAssetClassSelect,
        fetchGraphData,
        translateXsltToEnglish,
        fetchImpactAnalysis,
        fetchXPathImpactAnalysis,
    ]);


    return {
        // State variables
        state: {
            jurisdictions,
            fields,
            selectedJurisdiction,
            selectedType,
            selectedField,
            fieldDetails,
            isLoading,
            error,
            // EXPOSE THE NEW LIST STATE
            availableAssetClasses,
            selectedAssetClass,
            graphData,
            isGraphLoading,
            graphError,
            fetchXPathImpactAnalysis,
        },
        // Handlers
        handlers,
    };
};

export default useDashboardLogic;