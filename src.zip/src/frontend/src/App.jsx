import React, { useState } from 'react';
import useDashboardLogic from './hooks/useDashboardLogic';
import Sidebar from './components/Sidebar';
// Note: AppNavigator is no longer used for the top-level switch
// import AppNavigator from './components/AppNavigator';
import { Loader, AlertTriangle } from 'lucide-react';

// Make sure these paths are correct relative to App.jsx
import ExplorerView from './components/ExplorerView' // <--- ASSUME CORRECT RELATIVE PATH HERE
import XPathImpactAnalysisPage from './components/XPathImpactAnalysisPage' // <--- ASSUME CORRECT RELATIVE PATH HERE


// Define the top-level views/pages
const TOP_LEVEL_VIEWS = {
    EXPLORER: 'EXPLORER',
    XPATH_ANALYZER: 'XPATH_ANALYZER' // Corrected typo in the value
};

// --- Main Application Component (App.jsx - Now includes view state) ---
const App = () => {
    // State and handlers from the custom hook
    const { state, handlers } = useDashboardLogic();

    // 1. TOP-LEVEL VIEW STATE: Manages whether to show LogicPanel or the dedicated XPath page
    const [currentTopView, setCurrentTopView] = useState(TOP_LEVEL_VIEWS.EXPLORER);
    // State to hold the XPath object/string to analyze when switching views
    const [selectedXPathForAnalysis, setSelectedXPathForAnalysis] = useState(null);

    // 2. Handlers to pass down to trigger the view switch
    const handleSwitchToXPathAnalyzer = (xpathObject) => {
        setSelectedXPathForAnalysis(xpathObject);
        setCurrentTopView(TOP_LEVEL_VIEWS.XPATH_ANALYZER);
    };

    const handleBackToExplorer = () => {
        setSelectedXPathForAnalysis(null);
        setCurrentTopView(TOP_LEVEL_VIEWS.EXPLORER);
    };


    // Determine which main content component to render
    const renderMainContent = () => {
        if (currentTopView === TOP_LEVEL_VIEWS.XPATH_ANALYZER) {
            // Renders the standalone XPath Analyzer page
            return (
                <XPathImpactAnalysisPage
                    xpathObject={selectedXPathForAnalysis}
                    handlers={handlers}
                    onBackToLogic={handleBackToExplorer}
                    // Pass current data for context on the Analyzer page
                    field={state.selectedField}
                    assetClass={state.selectedAssetClass}
                />
            );
        }

        // Default: Render the Explorer View (which contains the LogicPanel and the switch button)
        return (
            <ExplorerView
                state={state}
                handlers={handlers}

                // Pass the switch handler down to ExplorerView, which uses it for the button and LogicPanel
                onSwitchToXPathAnalyzer={handleSwitchToXPathAnalyzer}
            />
        );
    };

    return (
        <div className="flex h-screen bg-slate-100">
            {/* 4. CONDITIONAL SIDEBAR RENDER */}
            {currentTopView === TOP_LEVEL_VIEWS.EXPLORER && (
                <Sidebar
                    state={state}
                    handlers={handlers}
                />
            )}

            {/* 5. MAIN CONTENT RENDER */}
            {renderMainContent()}
        </div>
    );
};

export default App;