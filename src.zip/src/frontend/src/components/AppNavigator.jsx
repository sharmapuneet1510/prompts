import React, { useState, useMemo, useCallback } from 'react';
import { Target, AlertTriangle, FileText, Code, Network, ChevronDown, Loader, AlertCircle } from 'lucide-react';

// Import your core components
import LogicPanel from './LogicPanel'; 
import XPathImpactAnalysisPage from './XPathImpactAnalysisPage'; 

// Import supporting components for the graph view (if they are not external)
// Assuming DependencyGraphModal content is rendered inline or Graph component is imported

const VIEWS = {
    FIELD_LOGIC: 'FIELD_LOGIC',
    XPATH_IMPACT: 'XPATH_IMPACT',
};

const AppNavigator = ({ 
    field, details, handlers, 
    availableAssetClasses, selectedAssetClass, handleAssetClassSelect,
    graphData, isGraphLoading, graphError 
}) => {
    
    // --- TOP-LEVEL STATE MANAGEMENT ---
    const [currentView, setCurrentView] = useState(VIEWS.FIELD_LOGIC);
    
    // Stores the XPath object or string used for the analysis page. 
    // This allows the XPath page to be pre-populated if triggered from LogicPanel.
    const [selectedXPathForImpact, setSelectedXPathForImpact] = useState(null);

    // Pre-filter the logic once here to simplify prop passing to LogicPanel (optional but clean)
    const activeLogic = useMemo(() => {
        if (!details || !selectedAssetClass) return null;
        return details.find(logic => logic.assetClass === selectedAssetClass);
    }, [details, selectedAssetClass]);

    // Handler passed *down* to LogicPanel's XPathsList. 
    // It triggers the switch to the XPath Impact tab and provides the data.
    const handleTriggerXPathImpact = useCallback((xpathObject) => {
        setSelectedXPathForImpact(xpathObject);
        setCurrentView(VIEWS.XPATH_IMPACT); 
    }, []);

    // --- UI HELPERS ---
    
    const tabClasses = (view) => 
        `px-4 py-2 text-sm font-semibold border-b-2 transition-colors flex items-center gap-2 ${
            currentView === view
                ? 'border-indigo-600 text-indigo-700 bg-white'
                : 'border-transparent text-slate-500 hover:text-indigo-600 hover:border-slate-300'
        }`;

    // --- RENDER CURRENT VIEW CONTENT ---
    
    const renderContent = () => {
        if (!details || !activeLogic) {
             return (
                <div className="p-8 text-center bg-white rounded-xl shadow-xl border border-slate-200">
                    <Loader className="h-6 w-6 mx-auto mb-3 animate-spin text-indigo-500" />
                    <p className="text-xl font-medium text-slate-600">
                        {details ? 'Select an Asset Class to begin analysis.' : 'Loading field details...'}
                    </p>
                </div>
            );
        }

        switch (currentView) {
            case VIEWS.XPATH_IMPACT:
                return (
                    <XPathImpactAnalysisPage
                        xpathObject={selectedXPathForImpact}
                        handlers={handlers}
                        field={field}
                        assetClass={selectedAssetClass}
                        // Allows the XPath Page to send the user back to the main logic tab
                        onBackToLogic={() => {
                            setSelectedXPathForImpact(null);
                            setCurrentView(VIEWS.FIELD_LOGIC);
                        }}
                    />
                );
            case VIEWS.FIELD_LOGIC:
            default:
                // LogicPanel receives all necessary props to function intact,
                // plus the handler to trigger the XPath switch.
                return (
                    <LogicPanel
                        field={field}
                        details={details}
                        handlers={handlers}
                        availableAssetClasses={availableAssetClasses}
                        selectedAssetClass={selectedAssetClass}
                        handleAssetClassSelect={handleAssetClassSelect}
                        graphData={graphData}
                        isGraphLoading={isGraphLoading}
                        graphError={graphError}

                        // PROP TO ENABLE NAVIGATION TO THE OTHER TAB
                        onTriggerXPathImpact={handleTriggerXPathImpact}
                    />
                );
        }
    };


    // --- MAIN RENDER ---
    return (
        <div className="flex-1 p-4 overflow-y-auto bg-indigo-50">
            <div className="max-w-4xl mx-auto space-y-4">

                {/* Header Section (Field Info, Asset Class Selector) */}
                <div className="bg-white p-4 rounded-xl shadow-xl border-t-4 border-indigo-700">
                    <h2 className="text-xl font-extrabold text-slate-900 mb-2">{field.name}</h2>
                    <div className="flex items-center gap-4 border-t border-slate-200 pt-2 mt-2">
                        {/* ID */}
                        <div className="text-sm font-medium text-slate-500 flex items-center gap-1">
                            <Code className="h-4 w-4 text-indigo-500" />
                            <span className="text-slate-600">ID:</span>
                            <code className="bg-indigo-100 px-1.5 py-0.5 rounded text-indigo-800 font-mono text-xs shadow-sm">
                                {field.id}
                            </code>
                        </div>

                        {/* ASSET CLASS DROPDOWN */}
                        {availableAssetClasses && availableAssetClasses.length > 0 && (
                            <div className="relative inline-block">
                                <label className="text-sm font-medium text-indigo-700 mr-2">Asset Class:</label>
                                <select
                                    value={selectedAssetClass || ''}
                                    onChange={(e) => handleAssetClassSelect(e.target.value)}
                                    className="appearance-none bg-indigo-200 border border-indigo-400 text-indigo-900 text-sm font-semibold rounded-lg pr-7 pl-3 py-1 focus:ring-2 focus:ring-indigo-600 cursor-pointer shadow-md transition-all duration-200"
                                >
                                    {availableAssetClasses.map(assetClass => (
                                        <option key={assetClass} value={assetClass}>
                                            {assetClass}
                                        </option>
                                    ))}
                                </select>
                                <ChevronDown className="absolute right-1.5 top-1/2 transform translate-y-0.5 h-3.5 w-3.5 text-indigo-800 pointer-events-none" />
                            </div>
                        )}

                        {/* Note: The LogicPanel still likely renders its internal Graph Modal/Button
                            as that was part of the original "intact" design.
                            If the graph button should be here, the LogicPanel must remove it. */}
                    </div>
                </div>

                {/* --- NAVIGATION TABS --- */}
                <div className="flex bg-slate-100 rounded-t-xl shadow-md border-b border-slate-300">
                    <button onClick={() => setCurrentView(VIEWS.FIELD_LOGIC)} className={tabClasses(VIEWS.FIELD_LOGIC)}>
                        <FileText className="h-4 w-4" /> Field Logic & Impact
                    </button>

                    <button
                        onClick={() => {
                            // Allow direct access to the XPath Impact tab for manual input
                            setCurrentView(VIEWS.XPATH_IMPACT);
                        }}
                        className={tabClasses(VIEWS.XPATH_IMPACT)}
                    >
                        <AlertTriangle className="h-4 w-4 text-red-500" /> XPath Input Impact
                        {selectedXPathForImpact && currentView === VIEWS.XPATH_IMPACT && (
                            <span className="text-xs bg-red-500 text-white px-2 py-0.5 rounded-full ml-1">Analyzing</span>
                        )}
                    </button>
                </div>

                {/* --- CONTENT RENDER --- */}
                {renderContent()}

            </div>
        </div>
    );
};

export default AppNavigator;