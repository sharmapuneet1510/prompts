import React, { useState, useMemo, useCallback } from 'react';
import {
    Code, X, Zap, Network, GitBranch,
    ChevronDown, List, Database, Search, Target, FileText, Hash, AlertTriangle, Loader,
    Activity, Layout, User, AlertTriangle as AlertIcon, Eye, AlertCircle
} from 'lucide-react';
import { Prism as SyntaxHighlighter } from 'react-syntax-highlighter';
import { atomDark } from 'react-syntax-highlighter/dist/esm/styles/prism';

// =========================================================================
// 1. Placeholder/Helper Modals
// =========================================================================

const DependencyModal = ({ dependency, onClose }) => {
    if (!dependency) return null;

    return (
        <div className="fixed inset-0 bg-black bg-opacity-70 flex items-center justify-center z-[100]">
            <div className="bg-white rounded-xl shadow-2xl w-full max-w-3xl max-h-[90vh] overflow-hidden flex flex-col">
                <div className="p-4 border-b border-slate-200 flex justify-between items-center bg-indigo-600 text-white">
                    <h3 className="text-xl font-bold flex items-center gap-2">
                        <GitBranch className="h-5 w-5" />
                        Dependency Detail: {dependency.name}
                    </h3>
                    <button onClick={onClose} className="p-1 rounded-full hover:bg-indigo-700 transition-colors">
                        <X className="h-6 w-6" />
                    </button>
                </div>

                <div className="p-6 overflow-y-auto flex-1 space-y-4">
                    <div className="bg-indigo-50 p-4 rounded-lg border-l-4 border-indigo-500">
                        <p className="text-lg font-semibold text-slate-900 mb-1">{dependency.name}</p>
                        <p className="text-sm">
                            <span className="font-semibold text-slate-700">Type:</span> <code className="font-mono bg-indigo-100 text-indigo-700 px-2 py-1 rounded text-xs">{dependency.type || 'N/A'}</code>
                        </p>
                    </div>

                    <div className="space-y-3">
                        <div className="bg-slate-50 p-3 rounded-lg border border-slate-200">
                            <p className="text-sm font-semibold text-slate-800 mb-1">Source File</p>
                            <code className="font-mono text-slate-700 text-xs break-all">{dependency.source || 'N/A'}</code>
                        </div>

                        <div className="bg-slate-50 p-3 rounded-lg border border-slate-200">
                            <p className="text-sm font-semibold text-slate-800 mb-1">Target XPath</p>
                            <code className="font-mono text-slate-700 text-xs break-all">{dependency.xpath || 'N/A'}</code>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    );
};

const DependencyGraphModal = ({ isLoading, graphData, graphError, onClose }) => {
    return (
        <div className="fixed inset-0 bg-black bg-opacity-70 flex items-center justify-center z-[100]">
            <div className="bg-white rounded-xl shadow-2xl w-full max-w-5xl max-h-[90vh] overflow-hidden flex flex-col">
                <div className="p-4 border-b border-slate-200 flex justify-between items-center bg-indigo-600 text-white">
                    <h3 className="text-xl font-bold flex items-center gap-2">
                        <Network className="h-5 w-5" />
                        Logic Dependency Graph
                    </h3>
                    <button onClick={onClose} className="p-1 rounded-full hover:bg-indigo-700 transition-colors">
                        <X className="h-6 w-6" />
                    </button>
                </div>

                <div className="p-6 flex-1 overflow-y-auto overflow-x-auto text-center">
                    {isLoading ? (
                         <p className="flex items-center justify-center gap-2 text-lg font-semibold text-slate-700 p-12">
                            <Loader className="h-5 w-5 animate-spin" />
                            Graph is being generated... (This may take a moment)
                        </p>
                    ) : graphError ? (
                        <div className="bg-red-100 border-l-4 border-red-500 text-red-700 p-6 my-4" role="alert">
                            <p className="font-bold flex items-center gap-2"><AlertCircle className='h-5 w-5'/> Graph Error</p>
                            <p className="text-sm mt-1">{graphError}</p>
                        </div>
                    ) : (graphData && graphData.nodes && graphData.nodes.length > 0) ? (
                        <div className="min-h-[400px] flex items-center justify-center bg-slate-50 border border-dashed border-slate-300">
                            {/* In a real app, you would render a Vis.js or D3 graph here */}
                            <p className="text-slate-700 font-medium">Visualization Rendered Successfully (Nodes: {graphData.nodes.length}, Edges: {graphData.edges.length})

[Image of dependency graph]
 </p>
                        </div>
                    ) : (
                        <div className="text-center p-12 text-slate-500">
                            <GitBranch className='h-8 w-8 mx-auto mb-3'/>
                            <p className="text-lg">No dependency graph available for this field and asset class combination.</p>
                        </div>
                    )}
                </div>
            </div>
        </div>
    );
};

const TranslationModal = ({ isOpen, isLoading, onClose, result }) => {
    if (!isOpen) return null;

    const isError = result && result.error;
    const translationText = result ? (isError ? result.error : result.translatedText) : 'Translation in progress...';

    return (
        <div className="fixed inset-0 bg-black bg-opacity-70 flex items-center justify-center z-[100]">
            <div className="bg-white rounded-xl shadow-2xl w-full max-w-3xl max-h-[90vh] overflow-hidden flex flex-col">
                <div className="p-4 border-b border-slate-200 flex justify-between items-center bg-indigo-600 text-white">
                    <h3 className="text-xl font-bold flex items-center gap-2">
                        <Zap className="h-5 w-5" />
                        English Translation
                    </h3>
                    <button onClick={onClose} className="p-1 rounded-full hover:bg-indigo-700 transition-colors">
                        <X className="h-6 w-6" />
                    </button>
                </div>
                <div className="p-6 flex-1 overflow-y-auto">
                    {isLoading ? (
                        <div className="text-center p-8 text-indigo-500">
                            <Loader className="h-8 w-8 mx-auto animate-spin" />
                            <p className="mt-3">Translating XSLT to natural language...</p>
                        </div>
                    ) : (
                        <div className={`p-4 rounded-lg ${isError ? 'bg-red-50 border border-red-300 text-red-700' : 'bg-green-50 border border-green-300 text-slate-800'}`}>
                            {isError && <AlertCircle className="h-5 w-5 inline mr-2 text-red-500" />}
                            <p className="whitespace-pre-wrap text-sm">{translationText}</p>
                        </div>
                    )}
                </div>
            </div>
        </div>
    );
};


// =========================================================================
// 2. List Components
// =========================================================================

const DependenciesList = ({ dependencies, onSelect, searchTerm }) => {

    const filteredDependencies = useMemo(() => {
        if (!searchTerm) return dependencies;
        const lowerCaseSearch = searchTerm.toLowerCase();

        return dependencies.filter(dep => {
            const nameMatch = dep.name?.toLowerCase().includes(lowerCaseSearch);
            const typeMatch = dep.type?.toLowerCase().includes(lowerCaseSearch);
            const sourceMatch = dep.source?.toLowerCase().includes(lowerCaseSearch);
            const xpathMatch = dep.xpath?.toLowerCase().includes(lowerCaseSearch);

            return nameMatch || typeMatch || sourceMatch || xpathMatch;
        });
    }, [dependencies, searchTerm]);

    return (
        <div className="bg-white">
            <div className="max-h-96 overflow-y-auto">
                {filteredDependencies.length === 0 ? (
                    <div className="text-slate-500 italic p-4 text-sm bg-white border-t text-center">
                        {searchTerm ? `No dependencies found matching "${searchTerm}".` : 'No direct dependencies found.'}
                    </div>
                ) : (
                    <ul className="space-y-1 p-3">
                        {filteredDependencies.map((dep, index) => (
                            <li
                                key={index}
                                className="flex justify-between items-center bg-white p-3 rounded-md border border-slate-200 hover:bg-indigo-50 hover:border-indigo-400 transition-all duration-150 cursor-pointer text-sm shadow-sm"
                                onClick={() => onSelect(dep)}
                            >
                                <span className="font-medium text-slate-700 flex items-center gap-2 truncate">
                                    <List className="h-4 w-4 text-indigo-600" />
                                    {dep.name}
                                </span>
                                <span className={`text-xs font-semibold px-2 py-0.5 rounded-full flex-shrink-0 ${dep.type === 'field' ? 'bg-orange-100 text-orange-700' : 'bg-green-100 text-green-700'}`}>
                                    {dep.type}
                                </span>
                            </li>
                        ))}
                    </ul>
                )}
            </div>
        </div>
    );
};

const XPathsList = ({ xpaths, searchTerm }) => {

    const filteredXpaths = useMemo(() => {
        if (!searchTerm) return xpaths;
        const lowerCaseSearch = searchTerm.toLowerCase();

        return xpaths.filter(pathObject => {
            const nameMatch = pathObject.name?.toLowerCase().includes(lowerCaseSearch);
            const sourceMatch = pathObject.source?.toLowerCase().includes(lowerCaseSearch);
            const xpathMatch = pathObject.xpath?.toLowerCase().includes(lowerCaseSearch);

            return nameMatch || sourceMatch || xpathMatch;
        });
    }, [xpaths, searchTerm]);

    return (
        <div className="bg-white">
            <div className="max-h-96 overflow-y-auto">
                {filteredXpaths.length === 0 ? (
                    <div className="text-slate-500 italic p-4 text-sm bg-white text-center">
                        {searchTerm ? `No XPaths found matching "${searchTerm}".` : 'No direct XPath inputs found.'}
                    </div>
                ) : (
                    <div className="p-3">
                        <div className="overflow-x-auto">
                            <table className="min-w-full divide-y divide-slate-200 border border-slate-300 rounded-lg shadow-md">
                                <thead className="bg-indigo-100 sticky top-0 z-10">
                                    <tr>
                                        <th scope="col" className="px-3 py-2 text-left text-xs font-bold text-indigo-700 uppercase tracking-wider w-1/4">Name</th>
                                        <th scope="col" className="px-3 py-2 text-left text-xs font-bold text-indigo-700 uppercase tracking-wider w-1/4">Source</th>
                                        <th scope="col" className="px-3 py-2 text-left text-xs font-bold text-indigo-700 uppercase tracking-wider w-1/2">XPath</th>
                                    </tr>
                                </thead>
                                <tbody className="bg-white divide-y divide-slate-200">
                                    {filteredXpaths.map((pathObject, index) => (
                                        <tr key={index} className="hover:bg-slate-50 transition-colors">
                                            <td className="px-3 py-3 text-sm font-medium text-slate-900">{pathObject.name || 'N/A'}</td>
                                            <td className="px-3 py-3 text-sm text-slate-500">{pathObject.source || 'N/A'}</td>
                                            <td className="px-3 py-3 text-xs font-mono text-indigo-700 break-all">{pathObject.xpath || 'N/A'}</td>
                                        </tr>
                                    ))}
                                </tbody>
                            </table>
                        </div>
                    </div>
                )}
            </div>
        </div>
    );
};


// =========================================================================
// 3. Impact Analysis List Component
// =========================================================================

const ImpactedFieldsList = ({ fields }) => {
    return (
        <div className="bg-white">
            <div className="max-h-[60vh] overflow-y-auto p-3">
                {fields.length === 0 ? (
                    <div className="text-slate-500 italic p-4 text-sm bg-white text-center">
                        No downstream fields found using this field's output.
                    </div>
                ) : (
                    <ul className="space-y-2">
                        {fields.map((field, index) => (
                            <li
                                key={index}
                                className="flex justify-between items-center bg-yellow-50 p-3 rounded-md border border-yellow-300 transition-all duration-150 text-sm shadow-sm"
                            >
                                <div className="flex flex-col">
                                    <span className="font-semibold text-slate-800 flex items-center gap-2">
                                        <Eye className="h-4 w-4 text-yellow-700" />
                                        {field.fieldName}
                                    </span>
                                    <code className="text-xs font-mono text-yellow-800 mt-0.5">
                                        {field.fieldId} (Used in: {field.sourceFile || 'N/A'})
                                    </code>
                                </div>
                                <span className={`text-xs font-semibold px-2 py-0.5 rounded-full bg-indigo-100 text-indigo-700 flex-shrink-0`}>
                                    {field.assetClass || 'N/A'}
                                </span>
                            </li>
                        ))}
                    </ul>
                )}
            </div>
        </div>
    );
};

// =========================================================================
// 4. Field Impact Analysis Modal
// =========================================================================

const FieldImpactAnalysisModal = ({ isOpen, onClose, fieldId, assetClass, handlers }) => {
    const [impactedFields, setImpactedFields] = useState(null);
    const [isLoading, setIsLoading] = useState(false);
    const [error, setError] = useState(null);
    const [hasRun, setHasRun] = useState(false);

    // Run analysis when the modal is opened
    React.useEffect(() => {
        // Reset state when modal is closed
        if (!isOpen) {
            setHasRun(false);
            return;
        }

        // Only run if opened and hasn't run yet for current context
        if (isOpen && !hasRun) {
            const runAnalysis = async () => {
                setIsLoading(true);
                setError(null);
                setImpactedFields(null);

                try {
                    if (!handlers || typeof handlers.fetchImpactAnalysis !== 'function') {
                        throw new Error("API handler 'fetchImpactAnalysis' is missing or not a function.");
                    }

                    const results = await handlers.fetchImpactAnalysis(fieldId, assetClass);

                    if (!Array.isArray(results)) {
                         throw new Error("API response format is invalid. Expected an array of impacted field objects.");
                    }

                    setImpactedFields(results);
                    setHasRun(true); // Mark as run successfully
                } catch (err) {
                    console.error("Field Impact Analysis API Error:", err);
                    setError(err.message || "Failed to fetch field impact analysis.");
                } finally {
                    setIsLoading(false);
                }
            };
            runAnalysis();
        }
    }, [isOpen, fieldId, assetClass, handlers, hasRun]);


    if (!isOpen) return null;

    return (
        <div className="fixed inset-0 bg-black bg-opacity-70 flex items-center justify-center z-[100]">
            <div className="bg-white rounded-xl shadow-2xl w-full max-w-4xl max-h-[90vh] overflow-hidden flex flex-col">
                <div className="p-4 border-b border-slate-200 flex justify-between items-center bg-yellow-600 text-white flex-shrink-0">
                    <h3 className="text-xl font-bold flex items-center gap-3">
                        <Target className="h-5 w-5" />
                        Downstream Impact Analysis
                    </h3>
                    <button onClick={onClose} className="p-1 rounded-full hover:bg-yellow-700 transition-colors">
                        <X className="h-6 w-6" />
                    </button>
                </div>

                <div className="p-4 flex-shrink-0 border-b border-slate-200 bg-yellow-50">
                    <p className="text-sm text-slate-700 font-medium">
                        Analyzing the global impact of changes to:
                        <code className="bg-yellow-200 text-yellow-800 px-2 py-0.5 rounded ml-2 font-mono">{fieldId}</code>
                        in Asset Class:
                        <code className="bg-indigo-200 text-indigo-800 px-2 py-0.5 rounded ml-2 font-mono">{assetClass}</code>
                    </p>
                </div>

                <div className="flex-1 overflow-y-auto p-4 space-y-4">

                    {isLoading && (
                        <div className="text-center p-8 bg-slate-50 rounded-lg">
                            <Loader className="h-6 w-6 text-yellow-500 mx-auto mb-3 animate-spin" />
                            <p className="text-sm text-slate-700">Querying global dependency graph...</p>
                        </div>
                    )}

                    {error && (
                        <div className="bg-red-100 border-l-4 border-red-500 text-red-700 p-4" role="alert">
                            <p className="font-bold">Analysis Error</p>
                            <p className="text-sm">{error}</p>
                        </div>
                    )}

                    {impactedFields !== null && !isLoading && !error && (
                        <>
                            <div className="bg-yellow-100 p-4 rounded-lg border-l-4 border-yellow-500 shadow-md">
                                <h4 className="text-xl font-bold text-slate-800 mb-1">
                                    <Hash className="inline h-5 w-5 mr-2 text-yellow-700" />
                                    Total Downstream Fields Impacted: <span className="text-yellow-700">{impactedFields.length}</span>
                                </h4>
                            </div>
                            <ImpactedFieldsList fields={impactedFields} />
                        </>
                    )}
                </div>
            </div>
        </div>
    );
};


// =========================================================================
// 5. Main Logic Panel Component
// =========================================================================

const LogicPanel = ({
    field, details, handlers, graphData, isGraphLoading, graphError,
    availableAssetClasses, selectedAssetClass, handleAssetClassSelect,
}) => {
    // Component State (Hooks must be at the top level)
    const [selectedDependency, setSelectedDependency] = useState(null);
    const [isGraphModalOpen, setIsGraphModalOpen] = useState(false);
    const [isTranslateModalOpen, setIsTranslateModalOpen] = useState(false);
    const [translationResult, setTranslationResult] = useState(null);
    const [isTranslating, setIsTranslating] = useState(false);
    const [depSearchTerm, setDepSearchTerm] = useState('');
    const [xpathSearchTerm, setXpathSearchTerm] = useState('');

    // Impact Analysis State
    const [isImpactModalOpen, setIsImpactModalOpen] = useState(false);

    const closeDependencyModal = () => setSelectedDependency(null);

    const activeLogic = useMemo(() => {
        if (!details || !selectedAssetClass) return null;
        return details.find(logic => logic.assetClass === selectedAssetClass);
    }, [details, selectedAssetClass]);

    // --- HOOK FIX: All hooks must be defined before the conditional return ---
    // The handleToggleImpactAnalysis function uses the useCallback hook.

    const handleToggleImpactAnalysis = useCallback(() => {
        // Note: The modal runs its own fetch on open based on the passed fieldId/assetClass.
        setIsImpactModalOpen(prev => !prev);
    }, []);

    // --- END HOOK FIX ---


    if (!activeLogic) {
        return (
            <div className="p-8 text-center bg-white rounded-xl shadow-2xl m-6 border border-slate-200">
                <p className="text-xl font-medium text-slate-600">
                    {details ? 'Select an Asset Class from the dropdown to view its detailed logic.' : 'Loading field details...'}
                </p>
            </div>
        );
    }

    // --- FEATURE HANDLERS (Defined as regular functions, can be below the early return) ---

    const handleExpandLogic = async () => {
        if (!activeLogic || !activeLogic.codeSnippet) return;
        setIsTranslateModalOpen(true);
        setIsTranslating(true);
        setTranslationResult(null);

        try {
            const result = await handlers.translateXsltToEnglish(activeLogic.codeSnippet);
            if (result && result.explanation_markdown)
            {
                 setTranslationResult({ translatedText: result.explanation_markdown });
            } else {
                 setTranslationResult({ error: "Translation API returned an empty or unexpected result." });
            }

        } catch (error) {
            setTranslationResult({ error: error.message || "Failed to connect to the translation service." });
        } finally {
            setIsTranslating(false);
        }
    };

    const handleViewGraph = () => {
        // Call the graph fetch handler from the hook
        handlers.fetchGraphData(field.id, selectedAssetClass);

        // Open the modal immediately. The modal uses the hook's state props to display loading/data.
        setIsGraphModalOpen(true);
    };


    // --- RENDER ---

    return (
        <React.Fragment>
            <div className="flex-1 p-4 overflow-y-auto bg-indigo-50">
                <div className="max-w-4xl mx-auto space-y-4">

                    {/* Header Section (Primary Focus Card) */}
                    <div className="bg-white p-4 rounded-xl shadow-xl border-t-4 border-indigo-700">
                        <h2 className="text-xl font-extrabold text-slate-900 mb-2">{field.name}</h2>

                        <div className="flex items-center gap-4 border-t border-slate-200 pt-2 mt-2">
                            <div className="text-sm font-medium text-slate-500 flex items-center gap-1">
                                <Code className="h-4 w-4 text-indigo-500" />
                                <span className="text-slate-600">ID:</span>
                                <code className="bg-indigo-100 px-1.5 py-0.5 rounded text-indigo-800 font-mono text-xs shadow-sm">
                                    {field.id}
                                </code>
                            </div>

                            {/* ASSET CLASS DROPDOWN */}
                            {availableAssetClasses && availableAssetClasses.length > 0 && (
                                <div className="relative inline-block">
                                    <label className="text-sm font-medium text-indigo-700 mr-2">Asset Class:</label>
                                    <select
                                        value={selectedAssetClass || ''}
                                        onChange={(e) => handleAssetClassSelect(e.target.value)}
                                        className="appearance-none bg-indigo-200 border border-indigo-400 text-indigo-900 text-sm font-semibold rounded-lg pr-7 pl-3 py-1 focus:ring-2 focus:ring-indigo-600 cursor-pointer shadow-md transition-all duration-200"
                                    >
                                        {availableAssetClasses.map(assetClass => (
                                            <option key={assetClass} value={assetClass}>
                                                {assetClass}
                                            </option>
                                        ))}
                                    </select>
                                    <ChevronDown className="absolute right-1.5 top-1/2 transform translate-y-0.5 h-3.5 w-3.5 text-indigo-800 pointer-events-none" />
                                </div>
                            )}
                        </div>
                    </div>

                    {/* XSLT Code Viewer (Primary Content) */}
                    <div className="bg-white rounded-xl shadow-xl border border-slate-200 overflow-hidden">
                        <div className="bg-slate-700 px-4 py-2 border-b border-slate-600 flex justify-between items-center text-white">
                            <div className="flex items-center gap-2 font-semibold text-base">
                                <Code className="h-4 w-4 text-yellow-300" />
                                XSLT Logic <span className="text-sm font-normal text-slate-300 ml-1">({activeLogic.sourceFile})</span>
                            </div>

                            {/* BUTTON GROUP: Impact Analysis, Translate, View Graph */}
                            <div className="flex items-center gap-2">

                                {/* IMPACT ANALYSIS BUTTON (TRIGGER) */}
                                <button
                                    onClick={handleToggleImpactAnalysis}
                                    className="px-3 py-1.5 text-xs font-bold rounded-full bg-yellow-500 text-slate-800 hover:bg-yellow-600 transition-colors flex items-center gap-1 shadow-lg"
                                >
                                    <Target className="h-3.5 w-3.5" />
                                    Downstream Impact
                                </button>

                                {/* TRANSLATE BUTTON */}
                                <button
                                    onClick={handleExpandLogic}
                                    className="px-3 py-1.5 text-xs font-bold rounded-full bg-indigo-500 text-white hover:bg-indigo-600 transition-colors flex items-center gap-1 shadow-lg disabled:opacity-50"
                                    disabled={isTranslating}
                                >
                                    <Zap className="h-3.5 w-3.5" />
                                    {isTranslating ? 'Translating...' : 'Translate'}
                                </button>

                                {/* VIEW GRAPH BUTTON */}
                                <button
                                    onClick={handleViewGraph}
                                    className="px-3 py-1.5 text-xs font-bold rounded-full bg-indigo-500 text-white hover:bg-indigo-600 transition-colors flex items-center gap-1 shadow-lg disabled:opacity-50"
                                    disabled={isGraphLoading}
                                >
                                    <Network className="h-3.5 w-3.5" />
                                    {isGraphLoading ? 'Loading Graph...' : 'View Graph'}
                                </button>
                            </div>
                        </div>
                        <div className="text-sm">
                            <SyntaxHighlighter
                                language="xml"
                                style={atomDark}
                                customStyle={{
                                    margin: 0,
                                    padding: '1rem',
                                    maxHeight: '350px',
                                    overflowY: 'auto',
                                    backgroundColor: '#282c34'
                                }}
                            >
                                {activeLogic.codeSnippet || `// No code snippet available for ${field.name} in ${activeLogic.assetClass}`}
                            </SyntaxHighlighter>
                        </div>
                    </div>

                    {/* Dependencies and XPaths Sections */}
                    <div className="space-y-4">

                        {/* 1. Dependencies Section */}
                        <div className="bg-white rounded-xl shadow-xl border border-slate-200 overflow-hidden">
                            <div className="bg-indigo-600 text-white px-4 py-3 flex items-center justify-between gap-4">
                                <h3 className="text-lg font-bold flex items-center gap-3 flex-shrink-0">
                                    <GitBranch className="h-5 w-5 text-indigo-200" />
                                    Direct Dependencies ({activeLogic.dependencies?.length || 0})
                                </h3>
                                <div className="relative flex-grow">
                                    <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-indigo-300" />
                                    <input
                                        type="text"
                                        placeholder="Search dependencies..."
                                        value={depSearchTerm}
                                        onChange={(e) => setDepSearchTerm(e.target.value)}
                                        className="w-full pl-10 pr-4 py-1.5 text-sm border border-indigo-400 rounded-lg focus:ring-yellow-400 focus:border-yellow-400 transition-shadow shadow-sm bg-indigo-700 text-white placeholder-indigo-300"
                                    />
                                </div>
                            </div>
                            <div className="border-t border-indigo-700">
                                <DependenciesList
                                    dependencies={activeLogic.dependencies || []}
                                    onSelect={setSelectedDependency}
                                    searchTerm={depSearchTerm}
                                />
                            </div>
                        </div>

                        {/* 2. XPaths/Input Fields Section */}
                        <div className="bg-white rounded-xl shadow-xl border border-slate-200 overflow-hidden">
                            <div className="bg-indigo-600 text-white px-4 py-3 flex items-center justify-between gap-4">
                                <h3 className="text-lg font-bold flex items-center gap-3 flex-shrink-0">
                                    <Database className="h-5 w-5 text-indigo-200" />
                                    Input XPaths / Data Points ({activeLogic.xpaths?.length || 0})
                                </h3>
                                <div className="relative flex-grow">
                                    <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-indigo-300" />
                                    <input
                                        type="text"
                                        placeholder="Search XPaths..."
                                        value={xpathSearchTerm}
                                        onChange={(e) => setXpathSearchTerm(e.target.value)}
                                        className="w-full pl-10 pr-4 py-1.5 text-sm border border-indigo-400 rounded-lg focus:ring-yellow-400 focus:border-yellow-400 transition-shadow shadow-sm bg-indigo-700 text-white placeholder-indigo-300"
                                    />
                                </div>
                            </div>
                            <div className="border-t border-indigo-700">
                                <XPathsList
                                    xpaths={activeLogic.xpaths || []}
                                    searchTerm={xpathSearchTerm}
                                />
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            {/* MODAL RENDERINGS */}

            <DependencyModal
                dependency={selectedDependency}
                onClose={closeDependencyModal}
            />

            <TranslationModal
                isOpen={isTranslateModalOpen}
                isLoading={isTranslating}
                onClose={() => setIsTranslateModalOpen(false)}
                result={translationResult}
            />

            {isGraphModalOpen && (
                <DependencyGraphModal
                    isLoading={isGraphLoading}
                    graphData={graphData}
                    graphError={graphError}
                    onClose={() => setIsGraphModalOpen(false)}
                />
            )}

            {/* IMPACT ANALYSIS MODAL (New) */}
            <FieldImpactAnalysisModal
                isOpen={isImpactModalOpen}
                onClose={() => setIsImpactModalOpen(false)}
                fieldId={field.id}
                assetClass={selectedAssetClass}
                handlers={handlers}
            />

        </React.Fragment>
    );
};

export default LogicPanel;