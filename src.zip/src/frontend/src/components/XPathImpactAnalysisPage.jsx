// XPathImpactAnalysisPage.jsx (Updated for manual user input)

import React, { useState, useEffect, useCallback } from 'react';
import { AlertTriangle, Hash, Loader, AlertCircle, Search } from 'lucide-react';

// Placeholder for the list component (must be implemented or imported)
const XPathImpactedFieldsList = ({ fields }) => {
    // ... (Implementation of the list of fields impacted by an XPath) ...
    // Note: This component is assumed to be fully functional from previous steps.
    return (
         <ul className="space-y-2">
            {fields.length === 0 ? (
                <li className="text-slate-500 italic p-4 text-sm bg-white text-center">
                    No fields found that directly rely on this XPath.
                </li>
            ) : (
                fields.map((field, index) => (
                    <li key={index} className="flex justify-between items-center bg-red-50 p-3 rounded-md border border-red-300 text-sm shadow-sm">
                         <div className="flex flex-col">
                            <span className="font-semibold text-slate-800 flex items-center gap-2">
                                <AlertTriangle className="h-4 w-4 text-red-700" />
                                {field.fieldName}
                            </span>
                            <code className="text-xs font-mono text-red-800 mt-0.5">
                                {field.fieldId} (Found in: {field.sourceFile || 'N/A'})
                            </code>
                        </div>
                        <span className={`text-xs font-semibold px-2 py-0.5 rounded-full bg-indigo-100 text-indigo-700 flex-shrink-0`}>
                            {field.assetClass || 'N/A'}
                        </span>
                    </li>
                ))
            )}
        </ul>
    );
};


const XPathImpactAnalysisPage = ({ xpathObject: initialXPathObject, handlers, onBackToLogic }) => {

    // State for the text input field
    const [xpathInput, setXpathInput] = useState('');
    // State to hold the result of the analysis
    const [analysisResult, setAnalysisResult] = useState(null);
    const [isLoading, setIsLoading] = useState(false);
    const [error, setError] = useState(null);

    // Effect to pre-populate the input field if a selection was made from the LogicPanel
    useEffect(() => {
        if (initialXPathObject && initialXPathObject.xpath) {
            setXpathInput(initialXPathObject.xpath);
            // Automatically trigger the analysis for the pre-populated XPath
            runAnalysis(initialXPathObject.xpath, initialXPathObject.source);
        } else {
            // Clear results when switching if no object is provided
            setAnalysisResult(null);
        }
    }, [initialXPathObject]);


    // Core analysis function (can be triggered by form submission or useEffect)
    const runAnalysis = useCallback(async (xpath, source = 'N/A') => {
        if (!xpath || xpath.trim() === '') {
            setError("Please enter an XPath expression to analyze.");
            setAnalysisResult(null);
            return;
        }

        setIsLoading(true);
        setError(null);
        setAnalysisResult(null);

        try {
            // Simulate the API call using the input XPath
            const results = await handlers.fetchXPathImpactAnalysis(xpath, source);

            setAnalysisResult({
                xpath: xpath,
                source: source,
                fields: results || [], // Ensure it's an array
            });
        } catch (err) {
            setError(err.message || "Failed to connect to the XPath analysis service.");
        } finally {
            setIsLoading(false);
        }
    }, [handlers]);


    const handleSubmit = (e) => {
        e.preventDefault();
        runAnalysis(xpathInput, 'Manual Input'); // Use a generic source for manual entry
    };

    // --- RENDER ---

    return (
        <div className="p-4 bg-white rounded-b-xl shadow-lg mt-0">
            <div className="p-4 bg-red-50 border border-red-300 rounded-lg shadow-sm mb-4">
                <h3 className="text-lg font-bold text-slate-800 flex items-center mb-2">
                    <AlertTriangle className="h-5 w-5 mr-2 text-red-600" />
                    Analyze XPath Expression Impact
                </h3>
                <form onSubmit={handleSubmit} className="flex gap-2">
                    <div className="relative flex-grow">
                         <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-slate-400" />
                        <input
                            type="text"
                            value={xpathInput}
                            onChange={(e) => setXpathInput(e.target.value)}
                            placeholder="Enter XPath (e.g., $input/party/name)"
                            className="w-full pl-10 pr-4 py-2 border border-slate-300 rounded-lg focus:ring-red-500 focus:border-red-500 text-sm shadow-inner"
                            disabled={isLoading}
                        />
                    </div>
                    <button
                        type="submit"
                        disabled={isLoading || xpathInput.trim() === ''}
                        className="px-4 py-2 text-sm font-bold rounded-lg bg-red-600 text-white hover:bg-red-700 transition-colors disabled:opacity-50 flex items-center"
                    >
                        {isLoading ? <Loader className="h-4 w-4 animate-spin mr-2" /> : <Search className="h-4 w-4 mr-1" />}
                        Analyze
                    </button>
                    <button
                        type="button"
                        onClick={onBackToLogic}
                        className="px-3 py-2 text-sm font-semibold rounded-lg bg-slate-200 text-slate-700 hover:bg-slate-300 transition-colors"
                    >
                         Logic
                    </button>
                </form>
            </div>

            {/* --- RESULTS DISPLAY --- */}

            {error && (
                <div className="bg-red-100 border-l-4 border-red-500 text-red-700 p-4" role="alert">
                    <p className="font-bold">Analysis Error</p>
                    <p className="text-sm">{error}</p>
                </div>
            )}

            {analysisResult && !isLoading && !error && (
                <>
                    <div className="bg-red-100 p-4 rounded-lg border-l-4 border-red-500 shadow-md mb-4">
                        <h4 className="text-xl font-bold text-slate-800 mb-1">
                            <Hash className="inline h-5 w-5 mr-2 text-red-700" />
                            Total Fields Directly Impacted: <span className="text-red-700">{analysisResult.fields.length}</span>
                        </h4>
                        <p className="text-sm text-slate-700 mt-1">
                            Source: <code className="bg-slate-200 text-slate-700 px-1 py-0.5 rounded font-mono text-xs">{analysisResult.source}</code>
                        </p>
                    </div>

                    <XPathImpactedFieldsList fields={analysisResult.fields} />
                </>
            )}

            {!analysisResult && !isLoading && !error && (
                <div className="text-center p-12 text-slate-500 bg-slate-50 rounded-lg">
                    <AlertCircle className='h-8 w-8 mx-auto mb-3'/>
                    <p className="text-lg">Enter an XPath expression above to begin the impact analysis.</p>
                </div>
            )}
        </div>
    );
};

export default XPathImpactAnalysisPage;