import React from 'react';
import { Layers, FileCode, ChevronRight, AlertCircle } from 'lucide-react';

const ImpactPanel = ({ details }) => {
  // Safe check if details haven't loaded yet
  if (!details || !details.lineage) {
    return (
      <div className="w-80 bg-white border-l border-slate-200 p-4 flex flex-col items-center justify-center text-slate-400">
        <span className="text-sm">Loading impact analysis...</span>
      </div>
    );
  }

  return (
    <div className="w-80 bg-white border-l border-slate-200 p-4 overflow-y-auto h-full">
      <h3 className="font-bold text-slate-800 mb-6 flex items-center gap-2 pb-4 border-b border-slate-100">
        <Layers className="h-4 w-4 text-slate-600" />
        Impact Lineage
      </h3>

      <div className="space-y-8">

        {/* Direct Usage Section */}
        <div>
          <h4 className="text-xs font-bold text-slate-400 uppercase mb-3 flex items-center gap-2">
            Directly Used In
            <span className="bg-blue-100 text-blue-800 text-[10px] px-1.5 rounded-full">
              {details.lineage.direct.length}
            </span>
          </h4>
          <div className="space-y-2">
            {details.lineage.direct.map((item, idx) => (
              <div key={idx} className="flex items-start gap-3 p-3 bg-blue-50 rounded-md border border-blue-100 text-sm text-blue-900 shadow-sm">
                <FileCode className="h-4 w-4 mt-0.5 opacity-70" />
                <span className="leading-tight">{item}</span>
              </div>
            ))}
            {details.lineage.direct.length === 0 && (
              <p className="text-sm text-slate-400 italic">No direct usage detected.</p>
            )}
          </div>
        </div>

        {/* Indirect Impact Section */}
        <div className="relative pl-4 border-l-2 border-slate-100">
          <h4 className="text-xs font-bold text-slate-400 uppercase mb-3 flex items-center gap-2">
            Indirectly Affected
            {details.lineage.indirect.length > 0 && (
               <span className="bg-orange-100 text-orange-800 text-[10px] px-1.5 rounded-full">
                 {details.lineage.indirect.length}
               </span>
            )}
          </h4>

          <div className="space-y-2">
            {details.lineage.indirect.map((item, idx) => (
              <div key={idx} className="flex items-center gap-2 p-2 bg-slate-50 rounded border border-slate-100 text-sm text-slate-600 hover:bg-orange-50 hover:border-orange-100 hover:text-orange-900 transition-colors">
                <ChevronRight className="h-3 w-3 opacity-50" />
                <span>{item}</span>
              </div>
            ))}
             {details.lineage.indirect.length === 0 && (
              <p className="text-sm text-slate-400 italic">No indirect impact detected.</p>
            )}
          </div>

          {/* Warning Note for Operations Team */}
          {details.lineage.indirect.length > 0 && (
            <div className="mt-4 flex gap-2 p-2 bg-yellow-50 text-yellow-800 text-xs rounded border border-yellow-100">
              <AlertCircle className="h-4 w-4 shrink-0" />
              <p>Changing this logic may impact downstream reporting systems listed above.</p>
            </div>
          )}
        </div>

      </div>
    </div>
  );
};

export default ImpactPanel;