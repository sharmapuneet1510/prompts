import React, { useState, useMemo } from 'react';
import {
    Code, Activity, Layout, X, Zap, Network, GitBranch,
    AlertTriangle, Loader, User, ChevronDown, List, Database, Search
} from 'lucide-react';
import { Prism as SyntaxHighlighter } from 'react-syntax-highlighter';
import { atomDark } from 'react-syntax-highlighter/dist/esm/styles/prism';

import { Graphviz } from 'graphviz-react';

// =========================================================================
// 1. Dependency Modal Component (Kept unchanged)
// =========================================================================

const DependencyModal = ({ dependency, onClose }) => {
    if (!dependency) return null;

    return (
        <div className="fixed inset-0 bg-black bg-opacity-70 flex items-center justify-center z-[100]">
            <div className="bg-white rounded-xl shadow-2xl w-full max-w-3xl max-h-[90vh] overflow-hidden flex flex-col">
                <div className="p-4 border-b border-slate-200 flex justify-between items-center bg-indigo-600 text-white">
                    <h3 className="text-xl font-bold flex items-center gap-2">
                        <GitBranch className="h-5 w-5" />
                        Dependency Detail: {dependency.name}
                    </h3>
                    <button onClick={onClose} className="p-1 rounded-full hover:bg-indigo-700 transition-colors">
                        <X className="h-6 w-6" />
                    </button>
                </div>

                <div className="p-6 overflow-y-auto flex-1 space-y-4">
                    <div className="bg-indigo-50 p-4 rounded-lg border-l-4 border-indigo-500">
                        <p className="text-lg font-semibold text-slate-900 mb-1">{dependency.name}</p>
                        <p className="text-sm">
                            <span className="font-semibold text-slate-700">Type:</span> <code className="font-mono bg-indigo-100 text-indigo-700 px-2 py-1 rounded text-xs">{dependency.type || 'N/A'}</code>
                        </p>
                    </div>

                    <div className="space-y-3">
                        <div className="bg-slate-50 p-3 rounded-lg border border-slate-200">
                            <p className="text-sm font-semibold text-slate-800 mb-1">Source File</p>
                            <code className="font-mono text-slate-700 text-xs break-all">{dependency.source || 'N/A'}</code>
                        </div>

                        <div className="bg-slate-50 p-3 rounded-lg border border-slate-200">
                            <p className="text-sm font-semibold text-slate-800 mb-1">Target XPath</p>
                            <code className="font-mono text-slate-700 text-xs break-all">{dependency.xpath || 'N/A'}</code>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    );
};

// --- (Other Modals & Helper Components - Placeholder for brevity) ---

const DependencyGraphModal = ({ isLoading, onClose }) => { /* ... */ return null; };
const TranslationModal = ({ isOpen, isLoading, onClose }) => { /* ... */ return null; };


// =========================================================================
// 2. Dependencies List Component (Kept unchanged)
// =========================================================================

const DependenciesList = ({ dependencies, onSelect, searchTerm }) => {

    const filteredDependencies = useMemo(() => {
        if (!searchTerm) return dependencies;
        const lowerCaseSearch = searchTerm.toLowerCase();

        return dependencies.filter(dep => {
            const nameMatch = dep.name?.toLowerCase().includes(lowerCaseSearch);
            const typeMatch = dep.type?.toLowerCase().includes(lowerCaseSearch);
            const sourceMatch = dep.source?.toLowerCase().includes(lowerCaseSearch);
            const xpathMatch = dep.xpath?.toLowerCase().includes(lowerCaseSearch);

            return nameMatch || typeMatch || sourceMatch || xpathMatch;
        });
    }, [dependencies, searchTerm]);

    return (
        <div className="bg-white">
            <div className="max-h-96 overflow-y-auto">
                {filteredDependencies.length === 0 ? (
                    <div className="text-slate-500 italic p-4 text-sm bg-white border-t text-center">
                        {searchTerm ? `No dependencies found matching "${searchTerm}".` : 'No direct dependencies found.'}
                    </div>
                ) : (
                    <ul className="space-y-1 p-3">
                        {filteredDependencies.map((dep, index) => (
                            <li
                                key={index}
                                className="flex justify-between items-center bg-white p-3 rounded-md border border-slate-200 hover:bg-indigo-50 hover:border-indigo-400 transition-all duration-150 cursor-pointer text-sm shadow-sm"
                                onClick={() => onSelect(dep)}
                            >
                                <span className="font-medium text-slate-700 flex items-center gap-2 truncate">
                                    <List className="h-4 w-4 text-indigo-600" />
                                    {dep.name}
                                </span>
                                <span className={`text-xs font-semibold px-2 py-0.5 rounded-full flex-shrink-0 ${dep.type === 'field' ? 'bg-orange-100 text-orange-700' : 'bg-green-100 text-green-700'}`}>
                                    {dep.type}
                                </span>
                            </li>
                        ))}
                    </ul>
                )}
            </div>
        </div>
    );
};

// =========================================================================
// 3. XPaths List Component (CORRECTED IMPLEMENTATION)
// =========================================================================

const XPathsList = ({ xpaths, searchTerm }) => {

    const filteredXpaths = useMemo(() => {
        if (!searchTerm) return xpaths;
        const lowerCaseSearch = searchTerm.toLowerCase();

        return xpaths.filter(pathObject => {
            // Search across name, source, and xpath
            const nameMatch = pathObject.name?.toLowerCase().includes(lowerCaseSearch);
            const sourceMatch = pathObject.source?.toLowerCase().includes(lowerCaseSearch);
            const xpathMatch = pathObject.xpath?.toLowerCase().includes(lowerCaseSearch);

            return nameMatch || sourceMatch || xpathMatch;
        });
    }, [xpaths, searchTerm]);

    return (
        <div className="bg-white">
            <div className="max-h-96 overflow-y-auto">
                {filteredXpaths.length === 0 ? (
                    <div className="text-slate-500 italic p-4 text-sm bg-white text-center">
                        {searchTerm ? `No XPaths found matching "${searchTerm}".` : 'No direct XPath inputs found.'}
                    </div>
                ) : (
                    <div className="p-3">
                        <div className="overflow-x-auto">
                            <table className="min-w-full divide-y divide-slate-200 border border-slate-300 rounded-lg shadow-md">
                                <thead className="bg-indigo-100 sticky top-0 z-10">
                                    <tr>
                                        <th scope="col" className="px-3 py-2 text-left text-xs font-bold text-indigo-700 uppercase tracking-wider w-1/4">Name</th>
                                        <th scope="col" className="px-3 py-2 text-left text-xs font-bold text-indigo-700 uppercase tracking-wider w-1/4">Source</th>
                                        <th scope="col" className="px-3 py-2 text-left text-xs font-bold text-indigo-700 uppercase tracking-wider w-1/2">XPath</th>
                                    </tr>
                                </thead>
                                <tbody className="bg-white divide-y divide-slate-200">
                                    {filteredXpaths.map((pathObject, index) => (
                                        <tr key={index} className="hover:bg-slate-50 transition-colors">
                                            <td className="px-3 py-3 text-sm font-medium text-slate-900">{pathObject.name || 'N/A'}</td>
                                            <td className="px-3 py-3 text-sm text-slate-500">{pathObject.source || 'N/A'}</td>
                                            <td className="px-3 py-3 text-xs font-mono text-indigo-700 break-all">{pathObject.xpath || 'N/A'}</td>
                                        </tr>
                                    ))}
                                </tbody>
                            </table>
                        </div>
                    </div>
                )}
            </div>
        </div>
    );
};


// =========================================================================
// 5. Main Logic Panel Component - (Integration)
// =========================================================================

const LogicPanel = ({
    field, details, handlers, graphData, isGraphLoading, graphError,
    availableAssetClasses, selectedAssetClass, handleAssetClassSelect,
}) => {
    // Component State
    const [selectedDependency, setSelectedDependency] = useState(null);
    const [isGraphModalOpen, setIsGraphModalOpen] = useState(false);
    const [isTranslateModalOpen, setIsTranslateModalOpen] = useState(false);
    const [translationResult, setTranslationResult] = useState(null);
    const [isTranslating, setIsTranslating] = useState(false);

    // Search State for Dependencies/XPaths
    const [depSearchTerm, setDepSearchTerm] = useState('');
    const [xpathSearchTerm, setXpathSearchTerm] = useState('');


    const closeDependencyModal = () => setSelectedDependency(null);

    const activeLogic = useMemo(() => {
        if (!details || !selectedAssetClass) return null;
        return details.find(logic => logic.assetClass === selectedAssetClass);
    }, [details, selectedAssetClass]);

    if (!activeLogic) {
        return (
            <div className="p-8 text-center bg-white rounded-xl shadow-2xl m-6 border border-slate-200">
                <p className="text-xl font-medium text-slate-600">
                    {details ? 'Select an Asset Class from the dropdown to view its detailed logic.' : 'Loading field details...'}
                </p>
            </div>
        );
    }

    const handleExpandLogic = async () => { /* ... handler logic ... */ };
    const handleViewGraph = () => { /* ... handler logic ... */ };

    return (
        <React.Fragment>
            <div className="flex-1 p-4 overflow-y-auto bg-indigo-50">
                <div className="max-w-4xl mx-auto space-y-4">

                    {/* Header Section (Primary Focus Card) */}
                    <div className="bg-white p-4 rounded-xl shadow-xl border-t-4 border-indigo-700">
                        <h2 className="text-xl font-extrabold text-slate-900 mb-2">{field.name}</h2>

                        <div className="flex items-center gap-4 border-t border-slate-200 pt-2 mt-2">
                            <div className="text-sm font-medium text-slate-500 flex items-center gap-1">
                                <Code className="h-4 w-4 text-indigo-500" />
                                <span className="text-slate-600">ID:</span>
                                <code className="bg-indigo-100 px-1.5 py-0.5 rounded text-indigo-800 font-mono text-xs shadow-sm">
                                    {field.id}
                                </code>
                            </div>

                            {/* ASSET CLASS DROPDOWN: Compact Styling */}
                            {availableAssetClasses && availableAssetClasses.length > 0 && (
                                <div className="relative inline-block">
                                    <label className="text-sm font-medium text-indigo-700 mr-2">Asset Class:</label>
                                    <select
                                        value={selectedAssetClass || ''}
                                        onChange={(e) => handleAssetClassSelect(e.target.value)}
                                        className="appearance-none bg-indigo-200 border border-indigo-400 text-indigo-900 text-sm font-semibold rounded-lg pr-7 pl-3 py-1 focus:ring-2 focus:ring-indigo-600 cursor-pointer shadow-md transition-all duration-200"
                                    >
                                        {availableAssetClasses.map(assetClass => (
                                            <option key={assetClass} value={assetClass}>
                                                {assetClass}
                                            </option>
                                        ))}
                                    </select>
                                    <ChevronDown className="absolute right-1.5 top-1/2 transform translate-y-0.5 h-3.5 w-3.5 text-indigo-800 pointer-events-none" />
                                </div>
                            )}
                        </div>
                    </div>

                    {/* XSLT Code Viewer (Primary Content) */}
                    <div className="bg-white rounded-xl shadow-xl border border-slate-200 overflow-hidden">
                        <div className="bg-slate-700 px-4 py-2 border-b border-slate-600 flex justify-between items-center text-white">
                            <div className="flex items-center gap-2 font-semibold text-base">
                                <Code className="h-4 w-4 text-yellow-300" />
                                XSLT Logic <span className="text-sm font-normal text-slate-300 ml-1">({activeLogic.sourceFile})</span>
                            </div>

                            <div className="flex items-center gap-2">
                                {/* EXPAND LOGIC BUTTON (Green accent) */}
                                <button
                                    onClick={handleExpandLogic}
                                    className="px-3 py-1.5 text-xs font-bold rounded-full bg-green-500 text-white hover:bg-green-600 transition-colors flex items-center gap-1 shadow-lg disabled:opacity-50"
                                    disabled={isTranslating}
                                >
                                    <Zap className="h-3.5 w-3.5" />
                                    {isTranslating ? 'Translating...' : 'Translate'}
                                </button>

                                {/* VIEW GRAPH BUTTON (Indigo accent) */}
                                <button
                                    onClick={handleViewGraph}
                                    className="px-3 py-1.5 text-xs font-bold rounded-full bg-indigo-500 text-white hover:bg-indigo-600 transition-colors flex items-center gap-1 shadow-lg disabled:opacity-50"
                                    disabled={isGraphLoading}
                                >
                                    <Network className="h-3.5 w-3.5" />
                                    {isGraphLoading ? 'Loading Graph...' : 'View Graph'}
                                </button>
                            </div>
                        </div>
                        <div className="text-sm">
                            <SyntaxHighlighter
                                language="xml"
                                style={atomDark}
                                customStyle={{
                                    margin: 0,
                                    padding: '1rem',
                                    maxHeight: '350px',
                                    overflowY: 'auto',
                                    backgroundColor: '#282c34'
                                }}
                            >
                                {activeLogic.codeSnippet || `// No code snippet available for ${field.name} in ${activeLogic.assetClass}`}
                            </SyntaxHighlighter>
                        </div>
                    </div>

                    {/* Dependencies and XPaths (Vertical Stacked, Scrollable with Search) */}
                    <div className="space-y-4">

                        {/* 1. Dependencies Section (Full Width) */}
                        <div className="bg-white rounded-xl shadow-xl border border-slate-200 overflow-hidden">
                            {/* MODIFIED HEADER: Search Input integrated */}
                            <div className="bg-indigo-600 text-white px-4 py-3 flex items-center justify-between gap-4">
                                <h3 className="text-lg font-bold flex items-center gap-3 flex-shrink-0">
                                    <GitBranch className="h-5 w-5 text-indigo-200" />
                                    Direct Dependencies ({activeLogic.dependencies?.length || 0})
                                </h3>
                                <div className="relative flex-grow">
                                    <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-indigo-300" />
                                    <input
                                        type="text"
                                        placeholder="Search dependencies..."
                                        value={depSearchTerm}
                                        onChange={(e) => setDepSearchTerm(e.target.value)}
                                        className="w-full pl-10 pr-4 py-1.5 text-sm border border-indigo-400 rounded-lg focus:ring-yellow-400 focus:border-yellow-400 transition-shadow shadow-sm bg-indigo-700 text-white placeholder-indigo-300"
                                    />
                                </div>
                            </div>
                            <div className="border-t border-indigo-700">
                                <DependenciesList
                                    dependencies={activeLogic.dependencies}
                                    onSelect={setSelectedDependency}
                                    searchTerm={depSearchTerm} // Pass down search state
                                />
                            </div>
                        </div>

                        {/* 2. XPaths/Input Fields Section (Full Width) */}
                        <div className="bg-white rounded-xl shadow-xl border border-slate-200 overflow-hidden">
                            {/* MODIFIED HEADER: Search Input integrated */}
                            <div className="bg-indigo-600 text-white px-4 py-3 flex items-center justify-between gap-4">
                                <h3 className="text-lg font-bold flex items-center gap-3 flex-shrink-0">
                                    <Database className="h-5 w-5 text-indigo-200" />
                                    Input XPaths / Data Points ({activeLogic.xpaths?.length || 0})
                                </h3>
                                <div className="relative flex-grow">
                                    <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-indigo-300" />
                                    <input
                                        type="text"
                                        placeholder="Search XPaths..."
                                        value={xpathSearchTerm}
                                        onChange={(e) => setXpathSearchTerm(e.target.value)}
                                        className="w-full pl-10 pr-4 py-1.5 text-sm border border-indigo-400 rounded-lg focus:ring-yellow-400 focus:border-yellow-400 transition-shadow shadow-sm bg-indigo-700 text-white placeholder-indigo-300"
                                    />
                                </div>
                            </div>
                            <div className="border-t border-indigo-700">
                                <XPathsList
                                    xpaths={activeLogic.xpaths}
                                    searchTerm={xpathSearchTerm} // Pass down search state
                                />
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            {/* RESTORED: Dependency Modal */}
            <DependencyModal
                dependency={selectedDependency}
                onClose={closeDependencyModal}
            />
            {/* Other Modals (Using placeholders for this response) */}
            {isGraphModalOpen && (
                <DependencyGraphModal
                    isLoading={isGraphLoading}
                    onClose={() => setIsGraphModalOpen(false)}
                />
            )}
            <TranslationModal
                isOpen={isTranslateModalOpen}
                isLoading={isTranslating}
                onClose={() => setIsTranslateModalOpen(false)}
            />

        </React.Fragment>
    );
};

export default LogicPanel;