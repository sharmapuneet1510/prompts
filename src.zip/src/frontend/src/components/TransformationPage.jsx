// src/components/TransformationPage.jsx (FINAL, CLEANED-UP REVISION)
import React, { useState } from 'react';
import { Layers, FileCode, Zap, ChevronRight, Loader, Search } from 'lucide-react';
import dtccApi from '../api/dtccApi';
import { Prism as SyntaxHighlighter } from 'react-syntax-highlighter';
import { vscDarkPlus } from 'react-syntax-highlighter/dist/esm/styles/prism';


const TransformationPage = () => {
    const [xmlFoInput, setXmlFoInput] = useState('');
    const [xsltFoToTradeService, setXsltFoToTradeService] = useState('');
    const [tradeServiceXmlOutput, setTradeServiceXmlOutput] = useState(''); // Holds the middle column content
    const [troyKeyValue, setTroyKeyValue] = useState({});
    const [loading, setLoading] = useState(false);
    const [error, setError] = useState(null);
    const [troySearchTerm, setTroySearchTerm] = useState('');
    const [showXsltCode, setShowXsltCode] = useState(false); // State to toggle XSLT code view

    // --- MOCK XSLT Data for demonstration (Read-only XSLT) ---
    useState(() => {
        setXsltFoToTradeService(`<xsl:stylesheet version="1.0" xmlns:xsl="http://www.w3.org/1999/XSL/Transform">
  <xsl:output method="xml" indent="yes"/>

  <xsl:template match="/">
    <TradeServiceInput>
      <ID><xsl:value-of select="//trade/id"/></ID>
      <Notional><xsl:value-of select="//trade/amount"/></Notional>
      <BaseCurrency><xsl:value-of select="//trade/currency"/></BaseCurrency>
      <ProductType>SWAP</ProductType>
    </TradeServiceInput>
  </xsl:template>
</xsl:stylesheet>`);
    }, []);
    // -----------------------------------------------------------------------------------------


    const handleRunTransformation = async () => {
        if (!xmlFoInput || !xsltFoToTradeService) {
            setError("Please provide FO XML Input and ensure the XSLT code is loaded.");
            return;
        }

        setError(null);
        setLoading(true);
        setTradeServiceXmlOutput('');
        setTroyKeyValue({});

        try {
            const result = await dtccApi.runAdvancedTransformation(
                xmlFoInput,
                xsltFoToTradeService
            );

            // This result is the Trade Service XML, which is now the middle panel's content
            setTradeServiceXmlOutput(result.trade_service_xml);
            setTroyKeyValue(result.troy_key_value);

        } catch (e) {
            const errorMessage = e.response?.data?.error || "An unexpected error occurred during transformation.";
            setError(errorMessage);
        } finally {
            setLoading(false);
        }
    };

    // Filtering logic for the Troy Key-Value output
    const filteredTroyKeyValue = Object.entries(troyKeyValue).filter(([key, value]) => {
        const lowerSearch = troySearchTerm.toLowerCase();
        return key.toLowerCase().includes(lowerSearch) || String(value).toLowerCase().includes(lowerSearch);
    });

    const renderTroyKeyValue = () => {
        if (Object.keys(troyKeyValue).length === 0) {
            return <p className="text-slate-400 italic p-3">Run transformation to see Key-Value map.</p>;
        }
        if (filteredTroyKeyValue.length === 0 && troySearchTerm) {
             return <p className="text-slate-400 italic p-3">No results found for "{troySearchTerm}".</p>;
        }

        return (
            // Tabular Structure
            <div className="flex flex-col overflow-auto max-h-[calc(100vh-350px)] border border-slate-200 rounded">
                <div className="flex bg-slate-200 font-bold text-slate-800 sticky top-0 text-sm">
                    <span className="w-1/3 p-2">Troy Field (Key)</span>
                    <span className="flex-1 p-2">Value</span>
                </div>
                {filteredTroyKeyValue.map(([key, value]) => (
                    <div key={key} className="flex border-b border-slate-100 hover:bg-slate-50 text-xs">
                        <span className="font-mono text-slate-800 w-1/3 p-1.5 bg-slate-50 font-bold">{key}</span>
                        <span className="font-mono text-blue-700 flex-1 p-1.5 break-all">{value}</span>
                    </div>
                ))}
            </div>
        );
    };

    return (
        <div className="flex flex-col h-screen bg-slate-100 p-6 flex-1 overflow-hidden">
            <div className="flex justify-between items-center mb-6">
                <h1 className="text-2xl font-bold text-slate-800 flex items-center gap-3">
                    <Layers className="h-6 w-6 text-blue-600" />
                    Transformation Pipeline Tester (FO → Trade Service → Troy)
                </h1>

                {/* Run Button and XSLT Toggle */}
                <div className="flex items-center gap-4">
                    <button
                        onClick={() => setShowXsltCode(!showXsltCode)}
                        className={`text-sm px-3 py-1 rounded ${showXsltCode ? 'bg-orange-100 text-orange-700' : 'bg-slate-200 text-slate-600 hover:bg-slate-300'}`}
                    >
                        {showXsltCode ? 'Hide XSLT Code' : 'Show XSLT Code'}
                    </button>
                    <button
                        onClick={handleRunTransformation}
                        disabled={loading || !xsltFoToTradeService}
                        className="bg-green-600 text-white px-6 py-2 rounded-xl text-lg font-bold hover:bg-green-700 disabled:bg-green-400 transition-colors shadow-lg flex items-center gap-2"
                    >
                        {loading && <Loader className="animate-spin h-5 w-5" />}
                        {loading ? 'Processing...' : 'Run Transformation'}
                    </button>
                </div>
            </div>

            {/* Error Message */}
            {error && (
                <div className="text-red-600 text-center text-sm p-3 bg-red-50 border border-red-200 rounded-lg mb-6">
                    Error: {error}
                </div>
            )}

            {/* Main Comparison Grid (Three Columns) */}
            <div className="grid grid-cols-3 gap-6 flex-1 overflow-hidden">

                {/* COLUMN 1: FO XML Input (Editable) */}
                <div className="flex flex-col bg-white p-4 rounded-lg shadow-md border border-slate-200">
                    <label className="text-sm font-semibold text-slate-700 mb-2 flex items-center gap-2">
                        <Zap className="h-4 w-4 text-orange-600" />
                        1. **FO XML** (Front Office Source) - **Editable**
                    </label>
                    <textarea
                        className="flex-1 w-full mt-2 p-3 border border-slate-300 rounded text-xs font-mono resize-none focus:ring-blue-500 focus:border-blue-500"
                        placeholder="Paste FO Source XML here..."
                        value={xmlFoInput}
                        onChange={(e) => setXmlFoInput(e.target.value)}
                    />
                </div>

                {/* COLUMN 2: Trade Service XML Result (Intermediate Output) */}
                <div className="flex flex-col bg-white p-4 rounded-lg shadow-md border border-slate-200">
                    <label className="text-sm font-semibold text-slate-700 mb-2 flex items-center gap-2 justify-between">
                        <div className="flex items-center gap-2">
                            <FileCode className="h-4 w-4 text-purple-600" />
                            2. **Trade Service XML** (XSLT Result)
                        </div>
                        <span className="text-xs bg-slate-100 px-2 py-0.5 rounded text-slate-500">
                            XSLT is **Read-Only**
                        </span>
                    </label>

                    {/* Conditional Display: XSLT Code or XML Output */}
                    {showXsltCode ? (
                         <div className="flex-1 overflow-y-auto">
                            <SyntaxHighlighter language="xml" style={vscDarkPlus} customStyle={{margin: 0, padding: '1rem', minHeight: '100%'}}>
                                {xsltFoToTradeService || "XSLT not loaded."}
                            </SyntaxHighlighter>
                         </div>
                    ) : (
                        <textarea
                            readOnly
                            className="flex-1 w-full p-3 border border-slate-300 rounded text-xs font-mono resize-none bg-slate-50 text-slate-700"
                            placeholder="Run transformation to see Trade Service XML output..."
                            value={tradeServiceXmlOutput || (loading ? 'Processing...' : '')}
                        />
                    )}
                </div>

                {/* COLUMN 3: Troy Key-Value Output (Final Stage Result) */}
                <div className="flex flex-col bg-white p-4 rounded-lg shadow-md border border-slate-200">
                    <label className="text-sm font-semibold text-slate-700 mb-2 flex items-center gap-2">
                        <ChevronRight className="h-4 w-4 text-cyan-600" />
                        3. **Troy Key-Value Pairs** (Final Mapped Output)
                    </label>

                    {/* Search Bar */}
                    <div className="relative mb-3 shrink-0">
                        <Search className="absolute left-3 top-2.5 h-4 w-4 text-slate-400" />
                        <input
                            type="text"
                            placeholder="Search Key or Value..."
                            className="w-full bg-slate-100 border border-slate-300 rounded py-2 pl-9 pr-2 text-sm focus:outline-none focus:border-blue-500"
                            value={troySearchTerm}
                            onChange={(e) => setTroySearchTerm(e.target.value)}
                        />
                    </div>

                    {/* Key-Value Table */}
                    <div className="flex-1 overflow-y-auto">
                        {renderTroyKeyValue()}
                    </div>
                </div>
            </div>
        </div>
    );
};

export default TransformationPage;