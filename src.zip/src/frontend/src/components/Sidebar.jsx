import React from 'react';
import {
    ChevronRight, Layout, List, Code, Zap, Globe, Folder, Search
} from 'lucide-react';

const Sidebar = ({ state, handlers }) => {
    // 1. Destructure the required state from the 'state' prop
    const {
        jurisdictions,
        selectedJurisdiction,
        selectedType,
        fields,
        selectedField
    } = state;

    // 2. Find the report types for the currently selected jurisdiction
    const currentJurisdictionConfig = jurisdictions?.find(
        j => j.jurisdiction === selectedJurisdiction
    );

    // The list of report types (e.g., ['TradeState', 'Valuation'])
    const reportTypes = currentJurisdictionConfig?.types || [];

    // --- Handlers ---

    // Handles Jurisdiction change
    const handleJurisdictionClick = (newJurisdiction) => {
        // When jurisdiction changes, default to the *first* report type of that new jurisdiction
        const newConfig = jurisdictions.find(j => j.jurisdiction === newJurisdiction);
        const defaultNewType = newConfig?.types[0] || null;

        handlers.handleSelectChange(newJurisdiction, defaultNewType);
    };

    // Handles Report Type change
    const handleTypeClick = (newType) => {
        handlers.handleSelectChange(selectedJurisdiction, newType);
    };

    return (
        // 1. Base Container: Fixed width, contrasting background, and strong shadow
        <div className="w-64 flex-shrink-0 bg-white shadow-2xl flex flex-col h-full border-r border-slate-100">

            {/* --- 2. Branded Header --- */}
            <div className="p-4 bg-indigo-700 text-white shadow-lg">
                <h2 className="text-xl font-extrabold flex items-center gap-2">
                    <Zap className="h-6 w-6 text-yellow-400" />
                    Logic Explorer
                </h2>
                <p className="text-xs text-indigo-300 mt-1">Configuration View</p>
            </div>

            {/* --- 3. Main Navigation Scroll Area --- */}
            <div className="flex-1 overflow-y-auto p-4 space-y-4">

                {/* ------------------------------- */}
                {/* --- Jurisdiction Selection (As interactive buttons/list) --- */}
                {/* ------------------------------- */}
                <div className="space-y-2">
                    <h3 className="text-sm font-bold uppercase text-slate-500 flex items-center gap-2 mb-2 pb-1 border-b border-slate-200">
                        <Globe className="h-4 w-4 text-indigo-500" />
                        Jurisdiction / Scope
                    </h3>

                    <div className="flex flex-wrap gap-2">
                        {jurisdictions?.map((j) => {
                            const isActive = j.jurisdiction === selectedJurisdiction;
                            return (
                                <button
                                    key={j.jurisdiction}
                                    onClick={() => handleJurisdictionClick(j.jurisdiction)}
                                    className={`
                                        text-xs font-semibold px-3 py-1.5 rounded-full transition-all duration-150 shadow-sm
                                        ${isActive
                                            ? 'bg-indigo-600 text-white border-indigo-700 hover:bg-indigo-700'
                                            : 'bg-slate-100 text-slate-700 border border-slate-300 hover:bg-indigo-50 hover:text-indigo-700'
                                        }
                                    `}
                                >
                                    {j.jurisdiction}
                                </button>
                            );
                        })}
                    </div>
                </div>

                {/* ------------------------------- */}
                {/* --- Report Type Selection (As interactive buttons/list) --- */}
                {/* ------------------------------- */}
                <div className="space-y-2 pt-2">
                    <h3 className="text-sm font-bold uppercase text-slate-500 flex items-center gap-2 mb-2 pb-1 border-b border-slate-200">
                        <Folder className="h-4 w-4 text-indigo-500" />
                        Report Type
                    </h3>
                    <div className="flex flex-wrap gap-2">
                        {reportTypes.map((type) => {
                            const isActive = type === selectedType;
                            return (
                                <button
                                    key={type}
                                    onClick={() => handleTypeClick(type)}
                                    className={`
                                        text-xs font-semibold px-3 py-1.5 rounded-full transition-all duration-150 shadow-sm
                                        ${isActive
                                            ? 'bg-green-600 text-white border-green-700 hover:bg-green-700'
                                            : 'bg-slate-100 text-slate-700 border border-slate-300 hover:bg-green-50 hover:text-green-700'
                                        }
                                    `}
                                >
                                    {type}
                                </button>
                            );
                        })}
                    </div>
                </div>

                {/* ------------------------------- */}
                {/* --- Field List (Core Navigation) --- */}
                {/* ------------------------------- */}
                <div className="space-y-1 pt-4">
                    <h3 className="text-sm font-bold uppercase text-slate-500 flex items-center gap-2 mb-2 pb-1 border-b border-slate-200">
                        <Search className="h-4 w-4 text-indigo-500" />
                        Fields ({fields?.length || 0})
                    </h3>

                    <ul className="space-y-1">
                        {fields?.map((field) => {
                            const isActive = selectedField?.id === field.id;
                            return (
                                <li
                                    key={field.id}
                                    onClick={() => handlers.selectField(field)}
                                    // 4. Enhanced Active/Hover States
                                    className={`
                                        flex justify-between items-center px-3 py-2 rounded-lg text-sm transition-all duration-150 cursor-pointer
                                        ${isActive
                                            ? 'bg-indigo-600 text-white shadow-lg font-semibold border-l-4 border-yellow-400'
                                            : 'text-slate-700 hover:bg-indigo-50 hover:text-indigo-800'
                                        }
                                    `}
                                >
                                    <span className="truncate flex items-center gap-2">
                                        <Code className={`h-4 w-4 ${isActive ? 'text-yellow-300' : 'text-slate-400'}`} />
                                        {field.name}
                                    </span>
                                    <ChevronRight className={`h-4 w-4 ${isActive ? 'text-white' : 'text-slate-400'}`} />
                                </li>
                            );
                        })}
                    </ul>

                    {fields?.length === 0 && (
                        <p className="text-sm text-slate-500 italic p-3 text-center">
                            Select jurisdiction and type to load fields.
                        </p>
                    )}
                </div>
            </div>

            {/* --- Footer/Status --- */}
             <div className="p-4 border-t bg-slate-50 text-xs text-slate-500 font-medium">
                <p>Status: Ready to explore</p>
            </div>

        </div>
    );
};

export default Sidebar;