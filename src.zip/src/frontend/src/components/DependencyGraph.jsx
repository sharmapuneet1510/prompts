// src/components/DependencyGraphModal.jsx

import React from 'react';
import { X, Network } from 'lucide-react';
import DependencyGraph from './DependencyGraph'; // Assuming you saved the previous code here

const DependencyGraphModal = ({
    graphData,
    isLoading,
    error,
    onClose,
    fieldName,
    assetClass
}) => {

    // Modal is rendered only when active
    if (!graphData && !isLoading && !error) return null;

    return (
        <div className="fixed inset-0 bg-black bg-opacity-70 flex items-center justify-center z-[100]">
            <div className="bg-white rounded-xl shadow-2xl w-[95%] max-w-6xl h-[90%] flex flex-col overflow-hidden">

                {/* Header */}
                <div className="p-4 border-b border-slate-200 flex justify-between items-center bg-indigo-600 text-white">
                    <h3 className="text-xl font-bold flex items-center gap-2">
                        <Network className="h-6 w-6" />
                        Dependency Graph: {fieldName}
                        <span className="text-sm font-normal opacity-80">({assetClass})</span>
                    </h3>
                    <button onClick={onClose} className="p-1 rounded-full hover:bg-indigo-500 transition-colors">
                        <X className="h-6 w-6" />
                    </button>
                </div>

                {/* Content */}
                <div className="flex-1 p-4 overflow-hidden">
                    <DependencyGraph
                        graphData={graphData}
                        isLoading={isLoading}
                        error={error}
                    />
                </div>
            </div>
        </div>
    );
};

export default DependencyGraphModal;