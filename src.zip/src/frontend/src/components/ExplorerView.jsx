import React from 'react';
// Assuming these imports are correct based on your previous context
import LogicPanel from './LogicPanel';
import { Loader, AlertTriangle, Search, ChevronDown } from 'lucide-react';

// --- Main Explorer View Component (Container for Logic) ---
// Receives onSwitchToXPathAnalyzer from App
const ExplorerView = ({ state, handlers, onSwitchToXPathAnalyzer }) => {
    const {
        selectedField,
        fieldDetails,
        isLoading,
        error,
        selectedJurisdiction,
        selectedType,

        // Graph State
        graphData,
        isGraphLoading,
        graphError,

        // Asset Class State
        availableAssetClasses,
        selectedAssetClass,
        fetchXPathImpactAnalysis,
    } = state;

    // --- Loading and Error States ---
    if (isLoading && !fieldDetails) {
        return (
            <div className="flex-1 flex items-center justify-center p-6 bg-slate-50">
                <div className="flex flex-col items-center text-slate-500">
                    <Loader className="h-8 w-8 animate-spin text-indigo-500" />
                    <p className="mt-3 text-lg">Loading Logic Details...</p>
                </div>
            </div>
        );
    }

    if (error && !selectedField) {
        return (
            <div className="flex-1 flex items-center justify-center p-6 bg-red-50">
                <div className="flex flex-col items-center text-red-700 p-6 border border-red-300 rounded-lg">
                    <AlertTriangle className="h-8 w-8" />
                    <p className="mt-3 text-lg font-semibold">Error Loading Data</p>
                    <p className="text-sm mt-1">{error}</p>
                </div>
            </div>
        );
    }


    // --- Content Panel Render ---
    if (selectedField) {
        return (
            <div className="flex-1 overflow-hidden flex flex-col">
                {/* 1. HEADER WITH NAVIGATION BUTTON */}
                <div className="px-6 pt-4 pb-2 bg-white border-b border-slate-200 shadow-sm flex justify-between items-center">
                    <h1 className="text-xl font-bold text-slate-900">
                        Explorer: {selectedJurisdiction} / {selectedType}
                    </h1>

                    {/* BUTTON TO MANUALLY SWITCH TO THE XPATH ANALYZER PAGE */}
                    <button
                        // Pass null to indicate a manual switch (not triggered by an existing XPath)
                        onClick={() => onSwitchToXPathAnalyzer(null)}
                        className="px-4 py-2 text-sm font-semibold rounded-lg bg-red-100 text-red-700 hover:bg-red-200 transition-colors flex items-center gap-2 shadow-sm"
                    >
                        <Search className="h-4 w-4" />
                        Go to XPath Analyzer
                    </button>
                </div>

                {/* Main Content Area */}
                <div className="flex-1 overflow-y-auto">
                    {fieldDetails ? (
                        <LogicPanel
                            field={selectedField}
                            details={fieldDetails}
                            handlers={handlers}
                            graphData={graphData}
                            isGraphLoading={isGraphLoading}
                            graphError={graphError}
                            availableAssetClasses={availableAssetClasses}
                            selectedAssetClass={selectedAssetClass}
                            handleAssetClassSelect={handlers.handleAssetClassSelect}

                            // PROP PASSED DOWN TO XPathsList's "Impact" Button.
                            // This handler switches the top-level view in App.jsx.
                            onTriggerXPathImpact={onSwitchToXPathAnalyzer}
                        />
                    ) : (
                        <div className="flex items-center justify-center h-full text-slate-500">
                             <p>Loading details for {selectedField.name}...</p>
                        </div>
                    )}
                </div>
            </div>
        );
    }

    // --- Default Empty State (When no field is selected) ---
    return (
        <div className="flex-1 flex items-center justify-center p-6 bg-slate-50">
            <p className="text-xl font-semibold text-slate-400">
                Select a Jurisdiction, Report Type, and Field to view its XSLT Logic.
            </p>
        </div>
    );
};

export default ExplorerView;